import type { Metadata } from "next"
import ClientComponent from "./ClientComponent"

export const metadata: Metadata = {
  title: "Prince Shamol - Web Developer | React.js, Node.js, bKash Payment Integration",
  description: "Best web development services in Bangladesh | React.js, Node.js, bKash payment integration",
  keywords: "Bangladesh Web Developer, e-commerce site developer, WooCommerce expert BD, React.js, Node.js",
}

export default function OurServices() {
  return <ClientComponent />
}
