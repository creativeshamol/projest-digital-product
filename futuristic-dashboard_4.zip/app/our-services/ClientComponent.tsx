"use client"
import Image from "next/image"
import { motion } from "framer-motion"
import {
  Code,
  ShoppingCart,
  Settings,
  CreditCard,
  Github,
  ExternalLink,
  Mail,
  Phone,
  MessageSquare,
  CheckCircle,
  Star,
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Separator } from "@/components/ui/separator"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"

const services = [
  {
    icon: Code,
    title: "ওয়েব ডেভেলপমেন্ট",
    description: "HTML, CSS, JavaScript দিয়ে আধুনিক ওয়েবসাইট তৈরি করি",
    features: ["রেসপন্সিভ ডিজাইন", "মডার্ন UI/UX", "পারফরম্যান্স অপ্টিমাইজেশন"],
  },
  {
    icon: ShoppingCart,
    title: "ই-কমার্স সাইট ডেভেলপমেন্ট",
    description: "WooCommerce/Shopify দিয়ে পূর্ণাঙ্গ ই-কমার্স সলিউশন",
    features: ["প্রোডাক্ট ম্যানেজমেন্ট", "পেমেন্ট গেটওয়ে", "ইনভেন্টরি সিস্টেম"],
  },
  {
    icon: Settings,
    title: "কাস্টম সফটওয়্যার সলিউশন",
    description: "আপনার ব্যবসার জন্য কাস্টম সফটওয়্যার তৈরি করি",
    features: ["CRM সিস্টেম", "ইনভেন্টরি ম্যানেজমেন্ট", "বিজনেস অটোমেশন"],
  },
  {
    icon: CreditCard,
    title: "পেমেন্ট গেটওয়ে ইন্টিগ্রেশন",
    description: "বাংলাদেশি পেমেন্ট গেটওয়ে ইন্টিগ্রেশন",
    features: ["bKash", "Nagad", "SSLCommerz", "Stripe"],
  },
]

const skills = [
  { name: "React.js", level: 90 },
  { name: "Next.js", level: 85 },
  { name: "Tailwind CSS", level: 95 },
  { name: "Node.js", level: 80 },
  { name: "Django", level: 75 },
  { name: "MongoDB", level: 85 },
  { name: "PostgreSQL", level: 80 },
]

const portfolio = [
  {
    id: 1,
    title: "ই-কমার্স ওয়েবসাইট",
    description: "WooCommerce দিয়ে তৈরি একটি পূর্ণাঙ্গ ই-কমার্স সাইট",
    image: "/portfolio/ecommerce.jpg",
    category: "e-commerce",
    github: "https://github.com/princeshamol",
    demo: "https://example.com",
  },
  {
    id: 2,
    title: "CRM সিস্টেম",
    description: "React এবং Node.js দিয়ে তৈরি একটি কাস্টমার রিলেশনশিপ ম্যানেজমেন্ট সিস্টেম",
    image: "/portfolio/crm.jpg",
    category: "software",
    github: "https://github.com/princeshamol",
    demo: "https://example.com",
  },
  {
    id: 3,
    title: "ফুড ডেলিভারি অ্যাপ",
    description: "React Native দিয়ে তৈরি একটি ফুড ডেলিভারি মোবাইল অ্যাপ",
    image: "/portfolio/food-delivery.jpg",
    category: "mobile",
    github: "https://github.com/princeshamol",
    demo: "https://example.com",
  },
  {
    id: 4,
    title: "স্কুল ম্যানেজমেন্ট সিস্টেম",
    description: "Django দিয়ে তৈরি একটি স্কুল ম্যানেজমেন্ট সিস্টেম",
    image: "/portfolio/school.jpg",
    category: "software",
    github: "https://github.com/princeshamol",
    demo: "https://example.com",
  },
]

const testimonials = [
  {
    id: 1,
    name: "রহিম আহমেদ",
    position: "CEO, TechBD",
    image: "/testimonials/rahim.jpg",
    text: "Prince Shamol একজন দক্ষ ডেভেলপার। আমাদের ই-কমার্স সাইট তিনি খুব দ্রুত এবং নিখুঁতভাবে তৈরি করে দিয়েছেন।",
  },
  {
    id: 2,
    name: "ফারহানা খান",
    position: "মার্কেটিং ম্যানেজার, DigitalBD",
    image: "/testimonials/farhana.jpg",
    text: "আমাদের কোম্পানির ওয়েবসাইট রিডিজাইন করার জন্য Prince Shamol কে ধন্যবাদ। সাইটটি এখন অনেক বেশি আকর্ষণীয় এবং ব্যবহারকারী বান্ধব হয়েছে।",
  },
  {
    id: 3,
    name: "কামাল হোসেন",
    position: "ফাউন্ডার, EduTech",
    image: "/testimonials/kamal.jpg",
    text: "Prince Shamol আমাদের অনলাইন লার্নিং প্ল্যাটফর্ম তৈরি করেছেন। তার কাজের মান এবং সময়ানুবর্তিতা অসাধারণ।",
  },
]

const clients = [
  { id: 1, name: "TechBD", logo: "/clients/techbd.png" },
  { id: 2, name: "Digital Marketing BD", logo: "/clients/digital-marketing.png" },
  { id: 3, name: "FoodPanda", logo: "/clients/foodpanda.png" },
  { id: 4, name: "EduTech", logo: "/clients/edutech.png" },
  { id: 5, name: "FinTech", logo: "/clients/fintech.png" },
]

export default function ClientComponent() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 text-white">
      {/* Animated background particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {Array.from({ length: 20 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full bg-purple-500/10"
            style={{
              width: Math.random() * 100 + 50,
              height: Math.random() * 100 + 50,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              x: [0, Math.random() * 100 - 50],
              y: [0, Math.random() * 100 - 50],
            }}
            transition={{
              duration: Math.random() * 10 + 10,
              repeat: Number.POSITIVE_INFINITY,
              repeatType: "reverse",
            }}
          />
        ))}
      </div>

      <div className="container mx-auto px-4 py-16 relative z-10">
        {/* Hero Section */}
        <motion.div
          className="flex flex-col md:flex-row items-center justify-between gap-8 mb-16"
          initial="hidden"
          animate="visible"
          variants={{
            hidden: { opacity: 0, y: 20 },
            visible: { opacity: 1, y: 0, transition: { duration: 0.6 } },
          }}
        >
          <div className="md:w-1/2">
            <motion.h1
              className="text-4xl md:text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-purple-400 to-pink-600"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.8 }}
            >
              আপনার ভিশন, আমার কোড
            </motion.h1>
            <motion.p
              className="text-xl text-gray-300 mb-6"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4, duration: 0.8 }}
            >
              আধুনিক ওয়েব ডেভেলপমেন্ট এবং সফটওয়্যার সলিউশন সার্ভিস
            </motion.p>
            <motion.div
              className="flex flex-wrap gap-4"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.6, duration: 0.8 }}
            >
              <Button size="lg" className="bg-purple-600 hover:bg-purple-700">
                <Mail className="mr-2 h-4 w-4" /> যোগাযোগ করুন
              </Button>
              <Button size="lg" variant="outline" className="border-purple-500 text-purple-400 hover:bg-purple-500/20">
                <Github className="mr-2 h-4 w-4" /> প্রজেক্ট দেখুন
              </Button>
            </motion.div>
          </div>
          <motion.div
            className="md:w-1/2 relative"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4, duration: 0.8 }}
          >
            <div className="relative w-64 h-64 mx-auto overflow-hidden rounded-full border-4 border-purple-500 shadow-lg shadow-purple-500/20">
              <Image
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/shamol1-BDWSiHZVSQAOXVJ19VyDgk3CJyN24e.png"
                alt="Prince Shamol"
                fill
                className="object-cover"
              />
            </div>
            <div className="absolute -bottom-4 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-purple-600 to-pink-600 px-6 py-2 rounded-full text-white font-bold shadow-lg">
              Prince Shamol
            </div>
          </motion.div>
        </motion.div>

        {/* Services Section */}
        <motion.section
          className="mb-20"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={{
            hidden: { opacity: 0 },
            visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
          }}
        >
          <div className="text-center mb-12">
            <Badge variant="outline" className="mb-2 text-purple-400 border-purple-400">
              সার্ভিসেস
            </Badge>
            <h2 className="text-3xl font-bold mb-4">আমার সার্ভিসেস</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              আপনার ব্যবসা বা প্রজেক্টের জন্য প্রয়োজনীয় সকল ধরনের ওয়েব ডেভেলপমেন্ট এবং সফটওয়্যার সলিউশন সার্ভিস প্রদান করি।
            </p>
          </div>

          <motion.div
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
            variants={{
              hidden: { opacity: 0 },
              visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
            }}
          >
            {services.map((service, index) => (
              <motion.div
                key={index}
                className="backdrop-blur-lg bg-white/5 border border-white/10 rounded-xl p-6 hover:border-purple-500/50 transition-all duration-300 hover:shadow-lg hover:shadow-purple-500/10"
                variants={{
                  hidden: { opacity: 0 },
                  visible: { opacity: 1, transition: { duration: 0.3 } },
                }}
                whileHover={{ y: -5 }}
              >
                <div className="bg-purple-500/20 p-3 rounded-lg w-fit mb-4">
                  <service.icon className="h-6 w-6 text-purple-400" />
                </div>
                <h3 className="text-xl font-bold mb-2">{service.title}</h3>
                <p className="text-gray-400 mb-4">{service.description}</p>
                <ul className="space-y-2">
                  {service.features.map((feature, i) => (
                    <li key={i} className="flex items-center text-sm text-gray-300">
                      <CheckCircle className="h-4 w-4 text-purple-400 mr-2" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </motion.div>
        </motion.section>

        {/* Skills Section */}
        <motion.section
          className="mb-20"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={{
            hidden: { opacity: 0 },
            visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
          }}
        >
          <div className="text-center mb-12">
            <Badge variant="outline" className="mb-2 text-purple-400 border-purple-400">
              স্কিলস
            </Badge>
            <h2 className="text-3xl font-bold mb-4">টেকনিক্যাল স্কিলস</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              আধুনিক টেকনোলজি এবং টুলস ব্যবহার করে আমি আপনার প্রজেক্ট সম্পন্ন করি।
            </p>
          </div>

          <div className="backdrop-blur-lg bg-white/5 border border-white/10 rounded-xl p-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-bold mb-4">ফ্রন্টএন্ড</h3>
                <div className="space-y-4">
                  {skills.slice(0, 3).map((skill, index) => (
                    <div key={index}>
                      <div className="flex justify-between mb-1">
                        <span>{skill.name}</span>
                        <span>{skill.level}%</span>
                      </div>
                      <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
                        <motion.div
                          className="h-full bg-gradient-to-r from-purple-500 to-pink-500"
                          initial={{ width: 0 }}
                          whileInView={{ width: `${skill.level}%` }}
                          transition={{ duration: 1, delay: index * 0.1 }}
                          viewport={{ once: true }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h3 className="text-xl font-bold mb-4">ব্যাকএন্ড</h3>
                <div className="space-y-4">
                  {skills.slice(3).map((skill, index) => (
                    <div key={index}>
                      <div className="flex justify-between mb-1">
                        <span>{skill.name}</span>
                        <span>{skill.level}%</span>
                      </div>
                      <div className="h-2 bg-gray-700 rounded-full overflow-hidden">
                        <motion.div
                          className="h-full bg-gradient-to-r from-purple-500 to-pink-500"
                          initial={{ width: 0 }}
                          whileInView={{ width: `${skill.level}%` }}
                          transition={{ duration: 1, delay: index * 0.1 }}
                          viewport={{ once: true }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </motion.section>

        {/* Portfolio Section */}
        <motion.section
          className="mb-20"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={{
            hidden: { opacity: 0 },
            visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
          }}
        >
          <div className="text-center mb-12">
            <Badge variant="outline" className="mb-2 text-purple-400 border-purple-400">
              পোর্টফোলিও
            </Badge>
            <h2 className="text-3xl font-bold mb-4">আমার প্রজেক্টস</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">বিভিন্ন ধরনের প্রজেক্ট যা আমি সম্পন্ন করেছি।</p>
          </div>

          <Tabs defaultValue="all" className="mb-8">
            <TabsList className="backdrop-blur-lg bg-white/5 border border-white/10 p-1 rounded-full mx-auto flex justify-center">
              <TabsTrigger value="all" className="rounded-full">
                সব
              </TabsTrigger>
              <TabsTrigger value="e-commerce" className="rounded-full">
                ই-কমার্স
              </TabsTrigger>
              <TabsTrigger value="software" className="rounded-full">
                সফটওয়্যার
              </TabsTrigger>
              <TabsTrigger value="mobile" className="rounded-full">
                মোবাইল অ্যাপ
              </TabsTrigger>
            </TabsList>

            <TabsContent value="all" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {portfolio.map((project) => (
                  <PortfolioCard key={project.id} project={project} />
                ))}
              </div>
            </TabsContent>

            <TabsContent value="e-commerce" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {portfolio
                  .filter((p) => p.category === "e-commerce")
                  .map((project) => (
                    <PortfolioCard key={project.id} project={project} />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="software" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {portfolio
                  .filter((p) => p.category === "software")
                  .map((project) => (
                    <PortfolioCard key={project.id} project={project} />
                  ))}
              </div>
            </TabsContent>

            <TabsContent value="mobile" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {portfolio
                  .filter((p) => p.category === "mobile")
                  .map((project) => (
                    <PortfolioCard key={project.id} project={project} />
                  ))}
              </div>
            </TabsContent>
          </Tabs>
        </motion.section>

        {/* Contact Form Section */}
        <motion.section
          className="mb-20"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={{
            hidden: { opacity: 0 },
            visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
          }}
        >
          <div className="text-center mb-12">
            <Badge variant="outline" className="mb-2 text-purple-400 border-purple-400">
              যোগাযোগ
            </Badge>
            <h2 className="text-3xl font-bold mb-4">আমার সাথে যোগাযোগ করুন</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              আপনার প্রজেক্ট সম্পর্কে আলোচনা করতে বা কোন প্রশ্ন থাকলে আমার সাথে যোগাযোগ করুন।
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2">
              <Card className="backdrop-blur-lg bg-white/5 border border-white/10 shadow-xl">
                <CardContent className="p-6">
                  <form className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label htmlFor="name" className="block text-sm font-medium">
                          আপনার নাম
                        </label>
                        <input
                          id="name"
                          type="text"
                          className="w-full px-4 py-2 bg-gray-800/50 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                          placeholder="আপনার নাম লিখুন"
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <label htmlFor="email" className="block text-sm font-medium">
                          ইমেইল
                        </label>
                        <input
                          id="email"
                          type="email"
                          className="w-full px-4 py-2 bg-gray-800/50 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                          placeholder="আপনার ইমেইল লিখুন"
                          required
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="phone" className="block text-sm font-medium">
                        ফোন নম্বর
                      </label>
                      <input
                        id="phone"
                        type="tel"
                        className="w-full px-4 py-2 bg-gray-800/50 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                        placeholder="আপনার ফোন নম্বর লিখুন"
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="project" className="block text-sm font-medium">
                        প্রজেক্টের বিবরণ
                      </label>
                      <textarea
                        id="project"
                        rows={5}
                        className="w-full px-4 py-2 bg-gray-800/50 border border-gray-700 rounded-md focus:outline-none focus:ring-2 focus:ring-purple-500"
                        placeholder="আপনার প্রজেক্ট সম্পর্কে বিস্তারিত লিখুন"
                        required
                      />
                    </div>
                    <div className="flex items-center">
                      <input
                        id="recaptcha"
                        type="checkbox"
                        className="h-4 w-4 rounded border-gray-700 text-purple-600 focus:ring-purple-500"
                      />
                      <label htmlFor="recaptcha" className="ml-2 block text-sm text-gray-400">
                        আমি রোবট নই (reCAPTCHA)
                      </label>
                    </div>
                    <Button
                      type="submit"
                      className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                    >
                      মেসেজ পাঠান
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>
            <div>
              <Card className="backdrop-blur-lg bg-white/5 border border-white/10 shadow-xl h-full">
                <CardContent className="p-6 flex flex-col h-full">
                  <h3 className="text-xl font-bold mb-6">যোগাযোগের তথ্য</h3>

                  <div className="space-y-6 flex-grow">
                    <div className="flex items-start">
                      <div className="bg-purple-500/20 p-3 rounded-lg mr-4">
                        <Mail className="h-5 w-5 text-purple-400" />
                      </div>
                      <div>
                        <h4 className="font-medium">ইমেইল</h4>
                        <a
                          href="mailto:creativeshamol75@gmail.com"
                          className="text-gray-400 hover:text-purple-400 transition-colors"
                        >
                          creativeshamol75@gmail.com
                        </a>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <div className="bg-purple-500/20 p-3 rounded-lg mr-4">
                        <Phone className="h-5 w-5 text-purple-400" />
                      </div>
                      <div>
                        <h4 className="font-medium">ফোন</h4>
                        <a href="tel:+8801893154507" className="text-gray-400 hover:text-purple-400 transition-colors">
                          +880 1893 154507
                        </a>
                      </div>
                    </div>

                    <div className="flex items-start">
                      <div className="bg-purple-500/20 p-3 rounded-lg mr-4">
                        <MessageSquare className="h-5 w-5 text-purple-400" />
                      </div>
                      <div>
                        <h4 className="font-medium">হোয়াটসঅ্যাপ</h4>
                        <a
                          href="https://wa.me/8801893154507"
                          className="text-gray-400 hover:text-purple-400 transition-colors"
                        >
                          +880 1893 154507
                        </a>
                      </div>
                    </div>
                  </div>

                  <div className="mt-8">
                    <h4 className="font-medium mb-3">সোশ্যাল মিডিয়া</h4>
                    <div className="flex space-x-3">
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <a
                              href="https://github.com/princeshamol"
                              target="_blank"
                              rel="noopener noreferrer"
                              className="bg-gray-800 p-2 rounded-full hover:bg-purple-600 transition-colors"
                            >
                              <Github className="h-5 w-5" />
                            </a>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>GitHub</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>

                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <a
                              href="https://linkedin.com"
                              target="_blank"
                              rel="noopener noreferrer"
                              className="bg-gray-800 p-2 rounded-full hover:bg-purple-600 transition-colors"
                            >
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="20"
                                height="20"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="lucide lucide-linkedin"
                              >
                                <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z" />
                                <rect width="4" height="12" x="2" y="9" />
                                <circle cx="4" cy="4" r="2" />
                              </svg>
                            </a>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>LinkedIn</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>

                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <a
                              href="https://facebook.com"
                              target="_blank"
                              rel="noopener noreferrer"
                              className="bg-gray-800 p-2 rounded-full hover:bg-purple-600 transition-colors"
                            >
                              <svg
                                xmlns="http://www.w3.org/2000/svg"
                                width="20"
                                height="20"
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                strokeWidth="2"
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                className="lucide lucide-facebook"
                              >
                                <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
                              </svg>
                            </a>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>Facebook</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </motion.section>

        {/* Testimonials Section */}
        <motion.section
          className="mb-20"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={{
            hidden: { opacity: 0 },
            visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
          }}
        >
          <div className="text-center mb-12">
            <Badge variant="outline" className="mb-2 text-purple-400 border-purple-400">
              টেস্টিমোনিয়ালস
            </Badge>
            <h2 className="text-3xl font-bold mb-4">ক্লায়েন্টদের মতামত</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">আমার সাথে কাজ করেছেন এমন কিছু ক্লায়েন্টের মতামত।</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {testimonials.map((testimonial) => (
              <motion.div
                key={testimonial.id}
                className="backdrop-blur-lg bg-white/5 border border-white/10 rounded-xl p-6 hover:border-purple-500/50 transition-all duration-300"
                variants={{
                  hidden: { opacity: 0 },
                  visible: { opacity: 1, transition: { duration: 0.3 } },
                }}
                whileHover={{ y: -5 }}
              >
                <div className="flex items-center mb-4">
                  <div className="relative w-12 h-12 rounded-full overflow-hidden mr-4 border-2 border-purple-500">
                    <Image
                      src={testimonial.image || "/placeholder.svg"}
                      alt={testimonial.name}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-bold">{testimonial.name}</h4>
                    <p className="text-sm text-gray-400">{testimonial.position}</p>
                  </div>
                </div>
                <p className="text-gray-300 italic">"{testimonial.text}"</p>
                <div className="flex mt-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.section>

        {/* Clients Section */}
        <motion.section
          className="mb-20"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={{
            hidden: { opacity: 0 },
            visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
          }}
        >
          <div className="text-center mb-12">
            <Badge variant="outline" className="mb-2 text-purple-400 border-purple-400">
              ক্লায়েন্টস
            </Badge>
            <h2 className="text-3xl font-bold mb-4">যাদের সাথে কাজ করেছি</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">বিভিন্ন কোম্পানি এবং ব্র্যান্ডের সাথে কাজ করার সুযোগ পেয়েছি।</p>
          </div>

          <div className="backdrop-blur-lg bg-white/5 border border-white/10 rounded-xl p-8">
            <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
              {clients.map((client) => (
                <motion.div
                  key={client.id}
                  className="flex items-center justify-center p-4 grayscale hover:grayscale-0 transition-all duration-300"
                  variants={{
                    hidden: { opacity: 0 },
                    visible: { opacity: 1, transition: { duration: 0.3 } },
                  }}
                  whileHover={{ scale: 1.05 }}
                >
                  <Image
                    src={client.logo || "/placeholder.svg"}
                    alt={client.name}
                    width={100}
                    height={100}
                    className="object-contain"
                  />
                </motion.div>
              ))}
            </div>
          </div>
        </motion.section>

        {/* FAQ Section */}
        <motion.section
          className="mb-20"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={{
            hidden: { opacity: 0 },
            visible: { opacity: 1, transition: { staggerChildren: 0.1 } },
          }}
        >
          <div className="text-center mb-12">
            <Badge variant="outline" className="mb-2 text-purple-400 border-purple-400">
              FAQ
            </Badge>
            <h2 className="text-3xl font-bold mb-4">সাধারণ প্রশ্ন</h2>
            <p className="text-gray-400 max-w-2xl mx-auto">আমার সার্ভিস সম্পর্কে সাধারণ কিছু প্রশ্নের উত্তর।</p>
          </div>

          <div className="backdrop-blur-lg bg-white/5 border border-white/10 rounded-xl p-8 max-w-3xl mx-auto">
            <div className="space-y-6">
              <div>
                <h4 className="text-lg font-medium mb-2">একটি প্রজেক্ট সম্পন্ন করতে কত সময় লাগে?</h4>
                <p className="text-gray-400">
                  প্রজেক্টের ধরন এবং জটিলতার উপর নির্ভর করে সময় নির্ধারণ করা হয়। একটি সাধারণ ওয়েবসাইট 1-2 সপ্তাহের মধ্যে, একটি ই-কমার্স
                  সাইট 3-4 সপ্তাহের মধ্যে এবং একটি জটিল সফটওয়্যার সিস্টেম 1-3 মাসের মধ্যে সম্পন্ন করা হয়।
                </p>
              </div>
              <Separator className="bg-gray-700" />
              <div>
                <h4 className="text-lg font-medium mb-2">আপনার সার্ভিসের মূল্য কত?</h4>
                <p className="text-gray-400">
                  প্রজেক্টের ধরন, জটিলতা এবং সময়সীমার উপর নির্ভর করে মূল্য নির্ধারণ করা হয়। বিস্তারিত জানতে আমার সাথে যোগাযোগ করুন।
                </p>
              </div>
              <Separator className="bg-gray-700" />
              <div>
                <h4 className="text-lg font-medium mb-2">প্রজেক্ট শুরু করার আগে কি অগ্রিম পেমেন্ট করতে হবে?</h4>
                <p className="text-gray-400">
                  হ্যাঁ, প্রজেক্ট শুরু করার আগে মোট মূল্যের 50% অগ্রিম পেমেন্ট করতে হবে। বাকি 50% প্রজেক্ট সম্পন্ন হওয়ার পর।
                </p>
              </div>
              <Separator className="bg-gray-700" />
              <div>
                <h4 className="text-lg font-medium mb-2">প্রজেক্ট সম্পন্ন হওয়ার পর কি সাপোর্ট পাওয়া যাবে?</h4>
                <p className="text-gray-400">
                  হ্যাঁ, প্রজেক্ট সম্পন্ন হওয়ার পর 1 মাস ফ্রি সাপোর্ট প্রদান করা হয়। এরপর মাসিক সাপোর্ট প্যাকেজ নিতে পারেন।
                </p>
              </div>
            </div>
          </div>
        </motion.section>

        {/* Call to Action */}
        <motion.section
          className="mb-10"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={{
            hidden: { opacity: 0 },
            visible: { opacity: 1, transition: { duration: 0.6 } },
          }}
        >
          <div className="backdrop-blur-lg bg-gradient-to-r from-purple-900/50 to-pink-900/50 border border-white/10 rounded-xl p-8 text-center">
            <h2 className="text-3xl font-bold mb-4">আপনার প্রজেক্ট নিয়ে আলোচনা করতে চান?</h2>
            <p className="text-gray-300 max-w-2xl mx-auto mb-6">
              আপনার আইডিয়া বাস্তবায়ন করতে আমার সাথে যোগাযোগ করুন। আমি আপনার প্রজেক্টকে সফল করতে সাহায্য করব।
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Button
                size="lg"
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
              >
                <Mail className="mr-2 h-4 w-4" /> ইমেইল পাঠান
              </Button>
              <Button size="lg" variant="outline" className="border-purple-500 text-purple-400 hover:bg-purple-500/20">
                <Phone className="mr-2 h-4 w-4" /> +880 1893 154507
              </Button>
            </div>
          </div>
        </motion.section>

        {/* Live Chat Widget (Commented out - Uncomment to activate) */}
        {/* 
        <script type="text/javascript">
          {`
            var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
            (function(){
              var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
              s1.async=true;
              s1.src='https://embed.tawk.to/YOUR_TAWK_ID/default';
              s1.charset='UTF-8';
              s1.setAttribute('crossorigin','*');
              s0.parentNode.insertBefore(s1,s0);
            })();
          `}
        </script>
        */}
      </div>
    </div>
  )
}

// Portfolio Card Component
function PortfolioCard({ project }) {
  return (
    <motion.div
      className="backdrop-blur-lg bg-white/5 border border-white/10 rounded-xl overflow-hidden hover:border-purple-500/50 transition-all duration-300"
      whileHover={{ y: -5 }}
    >
      <div className="relative aspect-video overflow-hidden">
        <Image
          src={project.image || "/placeholder.svg"}
          alt={project.title}
          fill
          className="object-cover transition-transform hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-0 hover:opacity-100 transition-opacity flex items-end p-4">
          <div>
            <h3 className="text-xl font-bold">{project.title}</h3>
            <p className="text-gray-300 text-sm">{project.description}</p>
            <div className="flex gap-2 mt-2">
              <Button size="sm" variant="outline" asChild className="rounded-full">
                <a href={project.github} target="_blank" rel="noopener noreferrer">
                  <Github className="h-4 w-4 mr-1" /> GitHub
                </a>
              </Button>
              <Button size="sm" variant="outline" asChild className="rounded-full">
                <a href={project.demo} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="h-4 w-4 mr-1" /> Live Demo
                </a>
              </Button>
            </div>
          </div>
        </div>
      </div>
      <div className="p-4">
        <h3 className="font-bold">{project.title}</h3>
        <p className="text-gray-400 text-sm line-clamp-2">{project.description}</p>
        <Badge variant="outline" className="mt-2 text-xs">
          {project.category}
        </Badge>
      </div>
    </motion.div>
  )
}
