"use client"

import { useState } from "react"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Search } from "lucide-react"

const faqs = [
  {
    id: "1",
    question: "ডিজিটাল প্রোডাক্ট কিনতে কি কি প্রয়োজন?",
    answer:
      "ডিজিটাল প্রোডাক্ট কিনতে আপনার একটি ইমেইল অ্যাকাউন্ট এবং পেমেন্ট মেথড (বিকাশ, নগদ, ক্রেডিট কার্ড ইত্যাদি) প্রয়োজন। কেনার পর, আপনি আপনার ইমেইলে ডাউনলোড লিংক পাবেন।",
  },
  {
    id: "2",
    question: "পেমেন্ট কিভাবে করব?",
    answer:
      "আমরা বিভিন্ন পেমেন্ট মেথড গ্রহণ করি, যেমন বিকাশ, নগদ, ক্রেডিট/ডেবিট কার্ড। চেকআউট পেজে আপনি আপনার পছন্দের পেমেন্ট মেথড বেছে নিতে পারেন।",
  },
  {
    id: "3",
    question: "প্রোডাক্ট ডাউনলোড করতে সমস্যা হলে কী করব?",
    answer: "ডাউনলোড সমস্যা হলে, আপনি আমাদের সাপোর্ট টিমের সাথে যোগাযোগ করতে পারেন। আমরা ২৪ ঘন্টার মধ্যে আপনার সমস্যা সমাধান করব।",
  },
  {
    id: "4",
    question: "রিফান্ড পলিসি কী?",
    answer:
      "আমরা ৭ দিনের রিফান্ড পলিসি অফার করি। যদি প্রোডাক্ট আপনার প্রত্যাশা পূরণ না করে, আপনি ৭ দিনের মধ্যে রিফান্ড অনুরোধ করতে পারেন। তবে, ডাউনলোড করা প্রোডাক্টের ক্ষেত্রে, আমরা কেস-বাই-কেস ভিত্তিতে রিফান্ড বিবেচনা করি।",
  },
  {
    id: "5",
    question: "প্রোডাক্টের আপডেট কিভাবে পাব?",
    answer:
      "যখন আপনি একটি প্রোডাক্ট কেনেন, আপনি সেই প্রোডাক্টের সকল আপডেট বিনামূল্যে পাবেন। আপডেট সম্পর্কে আপনাকে ইমেইলের মাধ্যমে জানানো হবে।",
  },
  {
    id: "6",
    question: "প্রোডাক্ট ব্যবহার করতে কোন লাইসেন্স প্রয়োজন?",
    answer:
      "প্রতিটি প্রোডাক্টের জন্য লাইসেন্স পলিসি আলাদা। কিছু প্রোডাক্ট একক ব্যবহারকারীর জন্য, আবার কিছু প্রোডাক্ট একাধিক ব্যবহারকারীর জন্য। প্রোডাক্ট ডিটেইল পেজে লাইসেন্স সম্পর্কে বিস্তারিত তথ্য দেওয়া আছে।",
  },
  {
    id: "7",
    question: "কাস্টম প্রোডাক্ট তৈরি করতে পারবেন?",
    answer: "হ্যাঁ, আমরা কাস্টম প্রোডাক্ট তৈরি করি। আপনার প্রয়োজন অনুযায়ী প্রোডাক্ট তৈরি করতে আমাদের সাথে যোগাযোগ করুন।",
  },
  {
    id: "8",
    question: "প্রোডাক্ট ব্যবহার করতে কোন টেকনিক্যাল সাপোর্ট পাব?",
    answer:
      "হ্যাঁ, আমরা সকল প্রোডাক্টের জন্য টেকনিক্যাল সাপোর্ট প্রদান করি। আপনি ইমেইল বা লাইভ চ্যাটের মাধ্যমে আমাদের সাথে যোগাযোগ করতে পারেন।",
  },
  {
    id: "9",
    question: "প্রোডাক্ট ডেমো দেখতে পারি?",
    answer: "হ্যাঁ, বেশিরভাগ প্রোডাক্টের জন্য আমরা ডেমো প্রদান করি। প্রোডাক্ট পেজে 'ডেমো দেখুন' বাটনে ক্লিক করে আপনি ডেমো দেখতে পারেন।",
  },
  {
    id: "10",
    question: "আমি কি একাধিক ডিভাইসে প্রোডাক্ট ব্যবহার করতে পারব?",
    answer:
      "এটি প্রোডাক্টের লাইসেন্স পলিসির উপর নির্ভর করে। কিছু প্রোডাক্ট একাধিক ডিভাইসে ব্যবহার করা যায়, আবার কিছু প্রোডাক্ট শুধুমাত্র একটি ডিভাইসে ব্যবহার করা যায়। প্রোডাক্ট ডিটেইল পেজে এই তথ্য উল্লেখ করা আছে।",
  },
]

export default function FAQPage() {
  const [searchQuery, setSearchQuery] = useState("")

  const filteredFaqs = faqs.filter(
    (faq) =>
      faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-4xl font-bold text-center mb-6">সাধারণ জিজ্ঞাসা</h1>

        <div className="mb-8">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-5 w-5" />
            <Input
              placeholder="আপনার প্রশ্ন খুঁজুন..."
              className="pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </div>

        <div className="bg-card rounded-lg border">
          <Accordion type="single" collapsible className="w-full">
            {filteredFaqs.length > 0 ? (
              filteredFaqs.map((faq) => (
                <AccordionItem key={faq.id} value={faq.id}>
                  <AccordionTrigger className="px-4 hover:no-underline">{faq.question}</AccordionTrigger>
                  <AccordionContent className="px-4 pb-4">{faq.answer}</AccordionContent>
                </AccordionItem>
              ))
            ) : (
              <div className="p-8 text-center">
                <p className="text-muted-foreground">কোন ফলাফল পাওয়া যায়নি। অন্য কিছু খুঁজুন।</p>
              </div>
            )}
          </Accordion>
        </div>

        <div className="mt-12 text-center">
          <h2 className="text-xl font-bold mb-4">আরও প্রশ্ন আছে?</h2>
          <p className="text-muted-foreground mb-6">আপনার প্রশ্নের উত্তর না পেলে, আমাদের সাথে যোগাযোগ করুন।</p>
          <Button asChild>
            <a href="/contact">যোগাযোগ করুন</a>
          </Button>
        </div>
      </div>
    </div>
  )
}
