import HeroSection from "@/components/home/hero-section"
import FeaturedProducts from "@/components/home/featured-products"
import Categories from "@/components/home/categories"
import SpecialOffers from "@/components/home/special-offers"
import Testimonials from "@/components/home/testimonials"
import Newsletter from "@/components/home/newsletter"

export default function Home() {
  return (
    <div className="container mx-auto px-4">
      <HeroSection />
      <Categories />
      <FeaturedProducts />
      <SpecialOffers />
      <Testimonials />
      <Newsletter />
    </div>
  )
}
