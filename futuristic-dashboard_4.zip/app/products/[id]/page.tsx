import { products } from "@/data/products"
import { notFound } from "next/navigation"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Star, Download, Share2 } from "lucide-react"
import ProductReviews from "@/components/product/product-reviews"
import RelatedProducts from "@/components/product/related-products"
import BuyNowButton from "@/components/product/buy-now-button"

export default function ProductPage({ params }: { params: { id: string } }) {
  const product = products.find((p) => p.id === params.id)

  if (!product) {
    notFound()
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Product Images */}
        <div className="relative aspect-square overflow-hidden rounded-lg border bg-background">
          <Image src={product.image || "/placeholder.svg"} alt={product.name} fill className="object-cover" />
        </div>

        {/* Product Info */}
        <div>
          <h1 className="text-3xl font-bold">{product.name}</h1>

          <div className="flex items-center gap-2 mt-2">
            <div className="flex">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  size={16}
                  className={i < product.rating ? "text-yellow-500 fill-yellow-500" : "text-gray-300"}
                />
              ))}
            </div>
            <span className="text-sm text-muted-foreground">({product.reviews} রিভিউ)</span>
          </div>

          <div className="mt-4">
            {product.discount ? (
              <div className="flex items-center gap-2">
                <span className="text-3xl font-bold">৳{product.price - (product.price * product.discount) / 100}</span>
                <span className="text-xl text-muted-foreground line-through">৳{product.price}</span>
                <Badge className="bg-red-500 hover:bg-red-600">{product.discount}% ছাড়</Badge>
              </div>
            ) : (
              <span className="text-3xl font-bold">৳{product.price}</span>
            )}
          </div>

          <div className="mt-6 space-y-2">
            <h3 className="font-medium">বিবরণ:</h3>
            <p className="text-muted-foreground">{product.description}</p>
          </div>

          <div className="mt-6 flex flex-col sm:flex-row gap-3">
            <BuyNowButton product={product} />

            <Button variant="outline" className="flex-1 gap-2">
              <Download size={18} />
              ডেমো ডাউনলোড
            </Button>

            <Button variant="outline" size="icon">
              <Share2 size={18} />
            </Button>
          </div>

          <div className="mt-6 text-sm text-muted-foreground">
            <p>
              ক্যাটাগরি: <span className="text-foreground">{product.category}</span>
            </p>
            <p className="mt-1">
              টাইপ: <span className="text-foreground">ডিজিটাল ডাউনলোড</span>
            </p>
          </div>
        </div>
      </div>

      {/* Product Details Tabs */}
      <div className="mt-12">
        <Tabs defaultValue="details">
          <TabsList className="w-full justify-start border-b rounded-none h-auto p-0">
            <TabsTrigger
              value="details"
              className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary py-3"
            >
              বিস্তারিত
            </TabsTrigger>
            <TabsTrigger
              value="reviews"
              className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary py-3"
            >
              রিভিউ ({product.reviews})
            </TabsTrigger>
          </TabsList>
          <TabsContent value="details" className="pt-4">
            <div className="prose max-w-none">
              <h3>প্রোডাক্ট বিবরণ</h3>
              <p>
                {product.description} এই প্রোডাক্টটি আপনাকে সাহায্য করবে আপনার ব্যবসা বা প্রজেক্ট আরও উন্নত করতে। এটি সহজেই ব্যবহার করা
                যায় এবং আপনার প্রয়োজনীয় সকল ফিচার রয়েছে।
              </p>

              <h3>ফিচারসমূহ</h3>
              <ul>
                <li>সহজ ব্যবহার</li>
                <li>আধুনিক ডিজাইন</li>
                <li>রেসপন্সিভ লেআউট</li>
                <li>দ্রুত লোডিং</li>
                <li>২৪/৭ সাপোর্ট</li>
              </ul>

              <h3>ব্যবহার নির্দেশিকা</h3>
              <p>প্রোডাক্টটি কেনার পর আপনি ইমেইলে ডাউনলোড লিংক পাবেন। লিংক থেকে ফাইল ডাউনলোড করে নির্দেশনা অনুযায়ী ব্যবহার করুন।</p>
            </div>
          </TabsContent>
          <TabsContent value="reviews" className="pt-4">
            <ProductReviews productId={product.id} />
          </TabsContent>
        </Tabs>
      </div>

      {/* Related Products */}
      <div className="mt-16">
        <h2 className="text-2xl font-bold mb-6">সম্পর্কিত প্রোডাক্ট</h2>
        <RelatedProducts currentProductId={product.id} category={product.category} />
      </div>
    </div>
  )
}
