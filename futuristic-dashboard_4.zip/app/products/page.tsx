import { ProductCard } from "@/components/product/product-card"
import { ProductFilters } from "@/components/product/product-filters"
import { products } from "@/data/products"
import { Button } from "@/components/ui/button"
import { ListFilter, Grid, List } from "lucide-react"

export default function ProductsPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">সকল প্রোডাক্ট</h1>

      <div className="flex flex-col md:flex-row gap-6">
        {/* Filters - Desktop */}
        <div className="hidden md:block w-64 shrink-0">
          <ProductFilters />
        </div>

        <div className="flex-1">
          {/* Mobile filter toggle */}
          <div className="flex justify-between items-center mb-4 md:hidden">
            <Button variant="outline" size="sm" className="flex items-center gap-2">
              <ListFilter size={16} />
              ফিল্টার
            </Button>

            <div className="flex gap-2">
              <Button variant="outline" size="icon" className="h-8 w-8">
                <Grid size={16} />
              </Button>
              <Button variant="outline" size="icon" className="h-8 w-8">
                <List size={16} />
              </Button>
            </div>
          </div>

          {/* Mobile filters (initially hidden) */}
          <div className="md:hidden mb-6">
            <ProductFilters />
          </div>

          {/* Desktop view options */}
          <div className="hidden md:flex justify-between items-center mb-4">
            <div className="text-sm text-muted-foreground">{products.length} প্রোডাক্ট পাওয়া গেছে</div>

            <div className="flex gap-2">
              <Button variant="outline" size="icon" className="h-8 w-8">
                <Grid size={16} />
              </Button>
              <Button variant="outline" size="icon" className="h-8 w-8">
                <List size={16} />
              </Button>
            </div>
          </div>

          {/* Products grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>

          {/* Pagination */}
          <div className="flex justify-center mt-8">
            <div className="flex gap-1">
              <Button variant="outline" size="icon" disabled>
                &lt;
              </Button>
              <Button variant="default" size="icon">
                1
              </Button>
              <Button variant="outline" size="icon">
                2
              </Button>
              <Button variant="outline" size="icon">
                3
              </Button>
              <Button variant="outline" size="icon">
                &gt;
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
