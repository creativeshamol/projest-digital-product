import Image from "next/image"
import { Button } from "@/components/ui/button"
import { CheckCircle2, Users, Award, Clock, ArrowRight } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl font-bold text-center mb-6">আমাদের সম্পর্কে</h1>

        <div className="relative aspect-video rounded-lg overflow-hidden mb-8">
          <Image src="/placeholder.svg?height=400&width=800" alt="About Us" fill className="object-cover" />
        </div>

        <div className="prose max-w-none">
          <h2>আমাদের গল্প</h2>
          <p>
            আমরা ২০১৮ সালে যাত্রা শুরু করি, যখন আমরা দেখলাম যে বাংলাদেশে ডিজিটাল প্রোডাক্টের একটি বড় চাহিদা রয়েছে। আমাদের লক্ষ্য ছিল একটি
            সহজ এবং নিরাপদ প্ল্যাটফর্ম তৈরি করা যেখানে ব্যবহারকারীরা উচ্চ মানের ডিজিটাল প্রোডাক্ট কিনতে পারেন।
          </p>
          <p>
            আজ, আমরা বাংলাদেশের অন্যতম বৃহত্তম ডিজিটাল প্রোডাক্ট মার্কেটপ্লেস হিসেবে গর্বিত। আমরা হাজার হাজার গ্রাহককে সেবা দিয়েছি এবং শত শত
            ডিজিটাল প্রোডাক্ট বিক্রি করেছি।
          </p>

          <h2>আমাদের মিশন</h2>
          <p>
            আমাদের মিশন হল বাংলাদেশের ডিজিটাল ইকোসিস্টেমকে শক্তিশালী করা এবং সবার জন্য উচ্চ মানের ডিজিটাল প্রোডাক্ট সহজলভ্য করা। আমরা বিশ্বাস
            করি যে প্রত্যেকেরই সেরা ডিজিটাল টুলস এবং রিসোর্সে অ্যাক্সেস থাকা উচিত।
          </p>

          <h2>আমাদের টিম</h2>
          <p>
            আমাদের টিম ডিজিটাল প্রোডাক্ট, ই-কমার্স এবং কাস্টমার সার্ভিসে অভিজ্ঞ পেশাদারদের নিয়ে গঠিত। আমরা সবসময় আমাদের গ্রাহকদের সর্বোত্তম
            অভিজ্ঞতা প্রদান করতে প্রতিশ্রুতিবদ্ধ।
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-12">
          <div className="bg-muted rounded-lg p-6">
            <h3 className="text-xl font-bold mb-4">আমাদের মূল্যবোধ</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                <span>গ্রাহক সন্তুষ্টি আমাদের প্রথম অগ্রাধিকার</span>
              </li>
              <li className="flex items-start">
                <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                <span>উচ্চ মানের প্রোডাক্ট নিশ্চিত করা</span>
              </li>
              <li className="flex items-start">
                <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                <span>সততা এবং স্বচ্ছতা বজায় রাখা</span>
              </li>
              <li className="flex items-start">
                <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                <span>নিরন্তর উন্নতি এবং নতুনত্ব</span>
              </li>
              <li className="flex items-start">
                <CheckCircle2 className="h-5 w-5 text-primary mr-2 mt-0.5" />
                <span>সামাজিক দায়বদ্ধতা</span>
              </li>
            </ul>
          </div>

          <div className="bg-muted rounded-lg p-6">
            <h3 className="text-xl font-bold mb-4">আমাদের পরিসংখ্যান</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center p-4">
                <Users className="h-8 w-8 mx-auto mb-2 text-primary" />
                <div className="text-2xl font-bold">১০,০০০+</div>
                <div className="text-sm text-muted-foreground">সন্তুষ্ট গ্রাহক</div>
              </div>
              <div className="text-center p-4">
                <Award className="h-8 w-8 mx-auto mb-2 text-primary" />
                <div className="text-2xl font-bold">৫০০+</div>
                <div className="text-sm text-muted-foreground">প্রোডাক্ট</div>
              </div>
              <div className="text-center p-4">
                <Clock className="h-8 w-8 mx-auto mb-2 text-primary" />
                <div className="text-2xl font-bold">৫+ বছর</div>
                <div className="text-sm text-muted-foreground">অভিজ্ঞতা</div>
              </div>
              <div className="text-center p-4">
                <CheckCircle2 className="h-8 w-8 mx-auto mb-2 text-primary" />
                <div className="text-2xl font-bold">৯৮%</div>
                <div className="text-sm text-muted-foreground">সন্তুষ্টি হার</div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-12 text-center">
          <h3 className="text-2xl font-bold mb-4">আমাদের সাথে যোগাযোগ করুন</h3>
          <p className="text-muted-foreground mb-6">
            আমাদের সম্পর্কে আরও জানতে বা আমাদের সাথে সহযোগিতা করতে আগ্রহী? আমাদের সাথে যোগাযোগ করুন।
          </p>
          <Button asChild>
            <a href="/contact" className="inline-flex items-center">
              যোগাযোগ করুন
              <ArrowRight className="ml-2 h-4 w-4" />
            </a>
          </Button>
        </div>
      </div>
    </div>
  )
}
