"use client"

import type React from "react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { MapPin, Phone, Mail, Clock, Facebook, Twitter, Instagram, Linkedin } from "lucide-react"

export default function ContactPage() {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Handle form submission
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-4xl font-bold text-center mb-6">যোগাযোগ করুন</h1>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-5xl mx-auto">
        <div>
          <div className="bg-muted rounded-lg p-6">
            <h2 className="text-2xl font-bold mb-6">আমাদের সাথে যোগাযোগ করুন</h2>

            <div className="space-y-6">
              <div className="flex items-start">
                <div className="bg-primary/10 p-3 rounded-full mr-4">
                  <MapPin className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">ঠিকানা</h3>
                  <p className="text-muted-foreground">১২৩ ডিজিটাল টাওয়ার, গুলশান-১, ঢাকা-১২১২, বাংলাদেশ</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="bg-primary/10 p-3 rounded-full mr-4">
                  <Phone className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">ফোন</h3>
                  <p className="text-muted-foreground">+৮৮০ ১৭১২ ৩৪৫ ৬৭৮</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="bg-primary/10 p-3 rounded-full mr-4">
                  <Mail className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">ইমেইল</h3>
                  <p className="text-muted-foreground">info@digitalproduct.com.bd</p>
                </div>
              </div>

              <div className="flex items-start">
                <div className="bg-primary/10 p-3 rounded-full mr-4">
                  <Clock className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-medium">কার্যালয় সময়</h3>
                  <p className="text-muted-foreground">শনিবার - বৃহস্পতিবার: সকাল ৯টা - বিকাল ৫টা</p>
                </div>
              </div>
            </div>

            <div className="mt-8">
              <h3 className="font-medium mb-4">সোশ্যাল মিডিয়া</h3>
              <div className="flex space-x-4">
                <a href="#" className="bg-primary/10 p-3 rounded-full hover:bg-primary/20">
                  <Facebook className="h-5 w-5 text-primary" />
                </a>
                <a href="#" className="bg-primary/10 p-3 rounded-full hover:bg-primary/20">
                  <Twitter className="h-5 w-5 text-primary" />
                </a>
                <a href="#" className="bg-primary/10 p-3 rounded-full hover:bg-primary/20">
                  <Instagram className="h-5 w-5 text-primary" />
                </a>
                <a href="#" className="bg-primary/10 p-3 rounded-full hover:bg-primary/20">
                  <Linkedin className="h-5 w-5 text-primary" />
                </a>
              </div>
            </div>
          </div>
        </div>

        <div>
          <div className="bg-card rounded-lg border p-6">
            <h2 className="text-2xl font-bold mb-6">মেসেজ পাঠান</h2>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">নাম</Label>
                  <Input id="name" placeholder="আপনার নাম" required />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">ইমেইল</Label>
                  <Input id="email" type="email" placeholder="আপনার ইমেইল" required />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="subject">বিষয়</Label>
                <Input id="subject" placeholder="মেসেজের বিষয়" required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="message">মেসেজ</Label>
                <Textarea id="message" placeholder="আপনার মেসেজ লিখুন..." rows={6} required />
              </div>

              <Button type="submit" className="w-full">
                মেসেজ পাঠান
              </Button>
            </form>
          </div>
        </div>
      </div>

      <div className="mt-12 max-w-5xl mx-auto">
        <div className="rounded-lg overflow-hidden h-96 bg-muted">
          {/* Google Map would go here */}
          <div className="w-full h-full flex items-center justify-center bg-muted">
            <MapPin className="h-12 w-12 text-muted-foreground opacity-50" />
          </div>
        </div>
      </div>
    </div>
  )
}
