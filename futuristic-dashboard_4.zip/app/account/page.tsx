"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { User, Package, Download, LogOut, Heart, Settings, FileText } from "lucide-react"
import Image from "next/image"

export default function AccountPage() {
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  if (!isLoggedIn) {
    return <LoginRegisterPage onLogin={() => setIsLoggedIn(true)} />
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">আমার অ্যাকাউন্ট</h1>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
        <div className="md:col-span-1">
          <div className="rounded-lg border bg-card p-6 sticky top-4">
            <div className="flex flex-col items-center mb-6">
              <div className="relative w-20 h-20 rounded-full overflow-hidden bg-muted mb-3">
                <Image src="/placeholder.svg?height=80&width=80" alt="Profile" fill className="object-cover" />
              </div>
              <h2 className="font-bold">রহিম আহমেদ</h2>
              <p className="text-sm text-muted-foreground">rahim@example.com</p>
            </div>

            <Tabs defaultValue="orders" orientation="vertical" className="w-full">
              <TabsList className="flex flex-col h-auto bg-transparent p-0 w-full">
                <TabsTrigger value="orders" className="justify-start mb-1 data-[state=active]:bg-muted">
                  <Package className="mr-2 h-4 w-4" />
                  অর্ডার হিস্ট্রি
                </TabsTrigger>
                <TabsTrigger value="downloads" className="justify-start mb-1 data-[state=active]:bg-muted">
                  <Download className="mr-2 h-4 w-4" />
                  ডাউনলোড
                </TabsTrigger>
                <TabsTrigger value="wishlist" className="justify-start mb-1 data-[state=active]:bg-muted">
                  <Heart className="mr-2 h-4 w-4" />
                  উইশলিস্ট
                </TabsTrigger>
                <TabsTrigger value="profile" className="justify-start mb-1 data-[state=active]:bg-muted">
                  <User className="mr-2 h-4 w-4" />
                  প্রোফাইল
                </TabsTrigger>
                <TabsTrigger value="settings" className="justify-start mb-1 data-[state=active]:bg-muted">
                  <Settings className="mr-2 h-4 w-4" />
                  সেটিংস
                </TabsTrigger>
              </TabsList>
            </Tabs>

            <Separator className="my-4" />

            <Button
              variant="outline"
              className="w-full justify-start text-red-500 hover:text-red-600 hover:bg-red-50"
              onClick={() => setIsLoggedIn(false)}
            >
              <LogOut className="mr-2 h-4 w-4" />
              লগআউট
            </Button>
          </div>
        </div>

        <div className="md:col-span-3">
          <Tabs defaultValue="orders">
            <TabsContent value="orders" className="mt-0">
              <div className="rounded-lg border bg-card">
                <div className="p-4 border-b">
                  <h2 className="font-bold text-lg">অর্ডার হিস্ট্রি</h2>
                </div>

                <div className="divide-y">
                  <OrderItem id="ORD-12345" date="১০ মে, ২০২৩" status="সম্পন্ন" total={1250} items={2} />
                  <OrderItem id="ORD-12344" date="০৫ মে, ২০২৩" status="সম্পন্ন" total={850} items={1} />
                  <OrderItem id="ORD-12343" date="২৮ এপ্রিল, ২০২৩" status="সম্পন্ন" total={2100} items={3} />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="downloads" className="mt-0">
              <div className="rounded-lg border bg-card">
                <div className="p-4 border-b">
                  <h2 className="font-bold text-lg">ডাউনলোড</h2>
                </div>

                <div className="divide-y">
                  <DownloadItem
                    name="প্রিমিয়াম ওয়েবসাইট টেমপ্লেট"
                    date="১০ মে, ২০২৩"
                    expires="১০ মে, ২০২৪"
                    downloads={3}
                    remaining={5}
                  />
                  <DownloadItem
                    name="ই-কমার্স ডাটাবেস সিস্টেম"
                    date="০৫ মে, ২০২৩"
                    expires="০৫ মে, ২০২৪"
                    downloads={1}
                    remaining={5}
                  />
                  <DownloadItem
                    name="ডিজিটাল মার্কেটিং ই-বুক"
                    date="২৮ এপ্রিল, ২০২৩"
                    expires="২৮ এপ্রিল, ২০২৪"
                    downloads={2}
                    remaining={5}
                  />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="wishlist" className="mt-0">
              <div className="rounded-lg border bg-card">
                <div className="p-4 border-b">
                  <h2 className="font-bold text-lg">উইশলিস্ট</h2>
                </div>

                <div className="p-4">
                  <p className="text-center text-muted-foreground py-8">আপনার উইশলিস্টে কোন আইটেম নেই।</p>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="profile" className="mt-0">
              <div className="rounded-lg border bg-card">
                <div className="p-4 border-b">
                  <h2 className="font-bold text-lg">প্রোফাইল</h2>
                </div>

                <div className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="name">নাম</Label>
                      <Input id="name" defaultValue="রহিম আহমেদ" />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="email">ইমেইল</Label>
                      <Input id="email" defaultValue="rahim@example.com" />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="phone">ফোন</Label>
                      <Input id="phone" defaultValue="01712345678" />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="address">ঠিকানা</Label>
                      <Input id="address" defaultValue="ঢাকা, বাংলাদেশ" />
                    </div>
                  </div>

                  <Button className="mt-6">আপডেট করুন</Button>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="settings" className="mt-0">
              <div className="rounded-lg border bg-card">
                <div className="p-4 border-b">
                  <h2 className="font-bold text-lg">সেটিংস</h2>
                </div>

                <div className="p-6">
                  <h3 className="font-medium mb-4">পাসওয়ার্ড পরিবর্তন</h3>

                  <div className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="current-password">বর্তমান পাসওয়ার্ড</Label>
                      <Input id="current-password" type="password" />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="new-password">নতুন পাসওয়ার্ড</Label>
                      <Input id="new-password" type="password" />
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="confirm-password">কনফার্ম পাসওয়ার্ড</Label>
                      <Input id="confirm-password" type="password" />
                    </div>
                  </div>

                  <Button className="mt-6">পাসওয়ার্ড পরিবর্তন করুন</Button>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}

function OrderItem({
  id,
  date,
  status,
  total,
  items,
}: {
  id: string
  date: string
  status: string
  total: number
  items: number
}) {
  return (
    <div className="p-4">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <FileText className="h-4 w-4 text-muted-foreground" />
            <span className="font-medium">{id}</span>
          </div>
          <div className="text-sm text-muted-foreground mt-1">
            {date} • {items} আইটেম
          </div>
        </div>

        <div className="flex items-center gap-4 mt-2 md:mt-0">
          <div className="text-sm">
            <span className="font-medium">৳{total}</span>
          </div>

          <div>
            <span className="inline-flex items-center rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-800">
              {status}
            </span>
          </div>

          <Button variant="outline" size="sm">
            বিস্তারিত
          </Button>
        </div>
      </div>
    </div>
  )
}

function DownloadItem({
  name,
  date,
  expires,
  downloads,
  remaining,
}: {
  name: string
  date: string
  expires: string
  downloads: number
  remaining: number
}) {
  return (
    <div className="p-4">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <div className="font-medium">{name}</div>
          <div className="text-sm text-muted-foreground mt-1">
            কেনা: {date} • মেয়াদ: {expires}
          </div>
          <div className="text-sm text-muted-foreground mt-1">
            ডাউনলোড: {downloads}/{downloads + remaining}
          </div>
        </div>

        <div className="mt-2 md:mt-0">
          <Button size="sm">
            <Download className="mr-2 h-4 w-4" />
            ডাউনলোড
          </Button>
        </div>
      </div>
    </div>
  )
}

function LoginRegisterPage({ onLogin }: { onLogin: () => void }) {
  const [activeTab, setActiveTab] = useState<"login" | "register">("login")

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-md mx-auto">
        <Tabs
          defaultValue="login"
          value={activeTab}
          onValueChange={(value) => setActiveTab(value as "login" | "register")}
        >
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="login">লগইন</TabsTrigger>
            <TabsTrigger value="register">রেজিস্টার</TabsTrigger>
          </TabsList>

          <TabsContent value="login" className="mt-6">
            <div className="rounded-lg border bg-card p-6">
              <h2 className="font-bold text-lg mb-4">লগইন করুন</h2>

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="login-email">ইমেইল</Label>
                  <Input id="login-email" type="email" placeholder="আপনার ইমেইল" />
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label htmlFor="login-password">পাসওয়ার্ড</Label>
                    <Button variant="link" className="p-0 h-auto text-sm">
                      পাসওয়ার্ড ভুলে গেছেন?
                    </Button>
                  </div>
                  <Input id="login-password" type="password" placeholder="আপনার পাসওয়ার্ড" />
                </div>

                <Button className="w-full" onClick={onLogin}>
                  লগইন
                </Button>
              </div>

              <div className="mt-4 text-center text-sm">
                <span className="text-muted-foreground">অ্যাকাউন্ট নেই?</span>{" "}
                <Button variant="link" className="p-0 h-auto" onClick={() => setActiveTab("register")}>
                  রেজিস্টার করুন
                </Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="register" className="mt-6">
            <div className="rounded-lg border bg-card p-6">
              <h2 className="font-bold text-lg mb-4">রেজিস্টার করুন</h2>

              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="register-name">নাম</Label>
                  <Input id="register-name" placeholder="আপনার নাম" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="register-email">ইমেইল</Label>
                  <Input id="register-email" type="email" placeholder="আপনার ইমেইল" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="register-phone">ফোন নম্বর</Label>
                  <Input id="register-phone" placeholder="আপনার ফোন নম্বর" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="register-password">পাসওয়ার্ড</Label>
                  <Input id="register-password" type="password" placeholder="পাসওয়ার্ড" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="register-confirm-password">কনফার্ম পাসওয়ার্ড</Label>
                  <Input id="register-confirm-password" type="password" placeholder="কনফার্ম পাসওয়ার্ড" />
                </div>

                <Button className="w-full" onClick={onLogin}>
                  রেজিস্টার
                </Button>
              </div>

              <div className="mt-4 text-center text-sm">
                <span className="text-muted-foreground">ইতিমধ্যে অ্যাকাউন্ট আছে?</span>{" "}
                <Button variant="link" className="p-0 h-auto" onClick={() => setActiveTab("login")}>
                  লগইন করুন
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
