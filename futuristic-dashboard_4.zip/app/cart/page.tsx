"use client"

import { useCart } from "@/context/cart-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Trash2, ShoppingBag, ArrowRight } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { useState } from "react"

export default function CartPage() {
  const { cart, removeFromCart, updateQuantity, clearCart } = useCart()
  const [couponCode, setCouponCode] = useState("")

  const subtotal = cart.reduce((total, item) => {
    const itemPrice = item.discount ? item.price - (item.price * item.discount) / 100 : item.price
    return total + itemPrice * item.quantity
  }, 0)

  const discount = 0 // This would be calculated based on coupon
  const total = subtotal - discount

  if (cart.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <div className="max-w-md mx-auto">
          <div className="rounded-full bg-muted w-16 h-16 flex items-center justify-center mx-auto mb-6">
            <ShoppingBag size={24} className="text-muted-foreground" />
          </div>
          <h1 className="text-2xl font-bold mb-2">আপনার কার্ট খালি</h1>
          <p className="text-muted-foreground mb-6">আপনার কার্টে কোন আইটেম নেই। আমাদের প্রোডাক্ট দেখুন এবং কার্টে যোগ করুন।</p>
          <Button asChild>
            <Link href="/products">প্রোডাক্ট দেখুন</Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">শপিং কার্ট</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="rounded-lg border bg-card">
            <div className="p-4 border-b">
              <div className="grid grid-cols-12 gap-4 text-sm font-medium">
                <div className="col-span-6">প্রোডাক্ট</div>
                <div className="col-span-2 text-center">মূল্য</div>
                <div className="col-span-2 text-center">পরিমাণ</div>
                <div className="col-span-2 text-center">মোট</div>
              </div>
            </div>

            <div className="divide-y">
              {cart.map((item) => {
                const itemPrice = item.discount ? item.price - (item.price * item.discount) / 100 : item.price
                const itemTotal = itemPrice * item.quantity

                return (
                  <div key={item.id} className="p-4">
                    <div className="grid grid-cols-12 gap-4 items-center">
                      <div className="col-span-6">
                        <div className="flex items-center gap-4">
                          <div className="relative w-16 h-16 rounded-md overflow-hidden bg-muted">
                            <Image
                              src={item.image || "/placeholder.svg"}
                              alt={item.name}
                              fill
                              className="object-cover"
                            />
                          </div>
                          <div>
                            <h3 className="font-medium">{item.name}</h3>
                            <button
                              onClick={() => removeFromCart(item.id)}
                              className="text-sm text-red-500 flex items-center gap-1 mt-1"
                            >
                              <Trash2 size={14} />
                              মুছুন
                            </button>
                          </div>
                        </div>
                      </div>

                      <div className="col-span-2 text-center">
                        <div className="font-medium">৳{itemPrice}</div>
                        {item.discount > 0 && (
                          <div className="text-sm text-muted-foreground line-through">৳{item.price}</div>
                        )}
                      </div>

                      <div className="col-span-2 text-center">
                        <div className="flex justify-center">
                          <div className="flex border rounded-md">
                            <button
                              className="px-2 py-1 border-r"
                              onClick={() => updateQuantity(item.id, Math.max(1, item.quantity - 1))}
                            >
                              -
                            </button>
                            <span className="px-3 py-1">{item.quantity}</span>
                            <button
                              className="px-2 py-1 border-l"
                              onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            >
                              +
                            </button>
                          </div>
                        </div>
                      </div>

                      <div className="col-span-2 text-center font-medium">৳{itemTotal}</div>
                    </div>
                  </div>
                )
              })}
            </div>

            <div className="p-4 border-t flex justify-between">
              <Button variant="outline" onClick={clearCart}>
                কার্ট খালি করুন
              </Button>

              <Button asChild variant="outline">
                <Link href="/products">শপিং চালিয়ে যান</Link>
              </Button>
            </div>
          </div>
        </div>

        <div className="lg:col-span-1">
          <div className="rounded-lg border bg-card p-4 sticky top-4">
            <h2 className="font-bold text-lg mb-4">অর্ডার সামারি</h2>

            <div className="space-y-2 mb-4">
              <div className="flex justify-between">
                <span className="text-muted-foreground">সাবটোটাল</span>
                <span>৳{subtotal}</span>
              </div>

              <div className="flex justify-between">
                <span className="text-muted-foreground">ডিসকাউন্ট</span>
                <span>৳{discount}</span>
              </div>

              <div className="border-t pt-2 mt-2 flex justify-between font-bold">
                <span>মোট</span>
                <span>৳{total}</span>
              </div>
            </div>

            <div className="mb-4">
              <div className="flex gap-2">
                <Input placeholder="কুপন কোড" value={couponCode} onChange={(e) => setCouponCode(e.target.value)} />
                <Button variant="outline">অ্যাপ্লাই</Button>
              </div>
            </div>

            <Button asChild className="w-full">
              <Link href="/checkout" className="flex items-center justify-center gap-2">
                চেকআউট করুন
                <ArrowRight size={16} />
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
