import { redirect } from "next/navigation"

export default function HireMePage() {
  redirect("/our-services")
  return null
}
