"use client"

import { products } from "@/data/products"
import { ProductCard } from "@/components/product/product-card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { motion } from "framer-motion"

export default function DigitalProductsPage() {
  // Get AI tools and digital subscriptions
  const aiProducts = products.filter(
    (product) =>
      product.category === "ai-tool" || product.category === "subscription" || product.category === "digital-asset",
  )

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-12">
        <motion.h1
          className="text-4xl font-bold mb-4"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          ডিজিটাল প্রোডাক্ট
        </motion.h1>
        <motion.p
          className="text-muted-foreground max-w-2xl mx-auto"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          আমাদের প্রিমিয়াম AI টুল, সাবস্ক্রিপশন এবং ডিজিটাল অ্যাসেট কালেকশন দেখুন। সর্বাধুনিক টেকনোলজি এবং টুলস সাশ্রয়ী মূল্যে।
        </motion.p>
      </div>

      {/* Featured banner */}
      <motion.div
        className="relative rounded-lg overflow-hidden mb-12 bg-gradient-to-r from-purple-600/20 to-blue-600/20 border border-purple-500/30"
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, delay: 0.3 }}
      >
        <div className="p-8 md:p-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <Badge className="mb-4 bg-primary hover:bg-primary">নতুন প্রোডাক্ট</Badge>
              <h2 className="text-3xl font-bold mb-4">AI টুল এবং ডিজিটাল সাবস্ক্রিপশন</h2>
              <p className="text-muted-foreground mb-6">
                আমাদের নতুন AI টুল এবং ডিজিটাল সাবস্ক্রিপশন কালেকশন দেখুন। Claude AI, ক্যাপকাট প্রো, HIX.AI, গ্রামারলি প্রিমিয়াম এবং আরও
                অনেক কিছু।
              </p>
              <Button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                সব প্রোডাক্ট দেখুন
              </Button>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="aspect-square rounded-lg overflow-hidden bg-white/10 backdrop-blur-sm p-4 flex items-center justify-center">
                <img src="/products/claude-ai.png" alt="Claude AI" className="max-h-full object-contain" />
              </div>
              <div className="aspect-square rounded-lg overflow-hidden bg-white/10 backdrop-blur-sm p-4 flex items-center justify-center">
                <img src="/products/hix-ai.png" alt="HIX.AI" className="max-h-full object-contain" />
              </div>
              <div className="aspect-square rounded-lg overflow-hidden bg-white/10 backdrop-blur-sm p-4 flex items-center justify-center">
                <img
                  src="/products/grammarly-premium.png"
                  alt="Grammarly Premium"
                  className="max-h-full object-contain"
                />
              </div>
              <div className="aspect-square rounded-lg overflow-hidden bg-white/10 backdrop-blur-sm p-4 flex items-center justify-center">
                <img src="/products/capcut-pro.png" alt="Capcut Pro" className="max-h-full object-contain" />
              </div>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Category tabs */}
      <Tabs defaultValue="all" className="mb-8">
        <TabsList className="w-full flex flex-wrap justify-start border-b rounded-none h-auto p-0 bg-transparent">
          <TabsTrigger
            value="all"
            className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary py-3"
          >
            সব প্রোডাক্ট
          </TabsTrigger>
          <TabsTrigger
            value="ai-tool"
            className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary py-3"
          >
            AI টুল
          </TabsTrigger>
          <TabsTrigger
            value="subscription"
            className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary py-3"
          >
            সাবস্ক্রিপশন
          </TabsTrigger>
          <TabsTrigger
            value="digital-asset"
            className="rounded-none data-[state=active]:border-b-2 data-[state=active]:border-primary py-3"
          >
            ডিজিটাল অ্যাসেট
          </TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {aiProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </TabsContent>

        <TabsContent value="ai-tool" className="mt-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {aiProducts
              .filter((product) => product.category === "ai-tool")
              .map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
          </div>
        </TabsContent>

        <TabsContent value="subscription" className="mt-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {aiProducts
              .filter((product) => product.category === "subscription")
              .map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
          </div>
        </TabsContent>

        <TabsContent value="digital-asset" className="mt-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {aiProducts
              .filter((product) => product.category === "digital-asset")
              .map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
          </div>
        </TabsContent>
      </Tabs>

      {/* Product comparison table */}
      <div className="mt-16">
        <h2 className="text-2xl font-bold mb-6">প্রোডাক্ট তুলনা</h2>
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-muted">
                <th className="p-4 text-left">প্রোডাক্ট</th>
                <th className="p-4 text-left">ক্যাটাগরি</th>
                <th className="p-4 text-left">মূল্য</th>
                <th className="p-4 text-left">রেটিং</th>
                <th className="p-4 text-left">বৈশিষ্ট্য</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              <tr className="hover:bg-muted/50">
                <td className="p-4 font-medium">Claude AI প্রিমিয়াম</td>
                <td className="p-4">AI টুল</td>
                <td className="p-4">৳4,499</td>
                <td className="p-4">4.8/5</td>
                <td className="p-4">AI চ্যাট, কন্টেন্ট জেনারেশন, ক্রিয়েটিভ রাইটিং</td>
              </tr>
              <tr className="hover:bg-muted/50">
                <td className="p-4 font-medium">ক্যাপকাট প্রো</td>
                <td className="p-4">সফটওয়্যার</td>
                <td className="p-4">৳9,999</td>
                <td className="p-4">4.7/5</td>
                <td className="p-4">ভিডিও এডিটিং, ইফেক্টস, ট্রানজিশন</td>
              </tr>
              <tr className="hover:bg-muted/50">
                <td className="p-4 font-medium">HIX.AI প্রিমিয়াম</td>
                <td className="p-4">AI টুল</td>
                <td className="p-4">৳4,999</td>
                <td className="p-4">4.6/5</td>
                <td className="p-4">AI টেক্সট হিউম্যানাইজেশন, AI ডিটেকশন বাইপাস</td>
              </tr>
              <tr className="hover:bg-muted/50">
                <td className="p-4 font-medium">এনভাটো প্রিমিয়াম ফাইল</td>
                <td className="p-4">ডিজিটাল অ্যাসেট</td>
                <td className="p-4">৳150</td>
                <td className="p-4">4.3/5</td>
                <td className="p-4">ডিজাইন টেমপ্লেট, থিম, প্লাগইন</td>
              </tr>
              <tr className="hover:bg-muted/50">
                <td className="p-4 font-medium">গ্রামারলি প্রিমিয়াম একাউন্ট</td>
                <td className="p-4">সাবস্ক্রিপশন</td>
                <td className="p-4">৳6,999</td>
                <td className="p-4">4.9/5</td>
                <td className="p-4">গ্রামার চেকিং, স্পেলিং করেকশন, রাইটিং সাজেশন</td>
              </tr>
              <tr className="hover:bg-muted/50">
                <td className="p-4 font-medium">ক্রিয়েটিভ ফেডিকা একাউন্ট</td>
                <td className="p-4">সাবস্ক্রিপশন</td>
                <td className="p-4">৳999</td>
                <td className="p-4">4.5/5</td>
                <td className="p-4">ডিজাইন টুলস, টেমপ্লেট, ক্রিয়েটিভ রিসোর্স</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* FAQ Section */}
      <div className="mt-16">
        <h2 className="text-2xl font-bold mb-6">সাধারণ জিজ্ঞাসা</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-card rounded-lg border p-6">
            <h3 className="font-bold mb-2">AI টুল কিনতে কি কি প্রয়োজন?</h3>
            <p className="text-muted-foreground">
              AI টুল কিনতে আপনার একটি ইমেইল অ্যাকাউন্ট এবং পেমেন্ট মেথড (বিকাশ, নগদ, রকেট) প্রয়োজন। কেনার পর, আপনি আপনার ইমেইলে
              অ্যাক্সেস ডিটেইলস পাবেন।
            </p>
          </div>
          <div className="bg-card rounded-lg border p-6">
            <h3 className="font-bold mb-2">সাবস্ক্রিপশন কত দিন চলবে?</h3>
            <p className="text-muted-foreground">
              সাবস্ক্রিপশন সাধারণত ১ মাস থেকে ১ বছর পর্যন্ত চলে, প্রোডাক্ট অনুযায়ী। প্রতিটি প্রোডাক্টের বিবরণে সাবস্ক্রিপশন মেয়াদ উল্লেখ করা
              আছে।
            </p>
          </div>
          <div className="bg-card rounded-lg border p-6">
            <h3 className="font-bold mb-2">রিফান্ড পলিসি কী?</h3>
            <p className="text-muted-foreground">
              ডিজিটাল প্রোডাক্টের ক্ষেত্রে, কেনার পর ৭ দিনের মধ্যে যদি প্রোডাক্ট কাজ না করে, আপনি রিফান্ড অনুরোধ করতে পারেন। তবে, ব্যবহার
              করা প্রোডাক্টের ক্ষেত্রে রিফান্ড দেওয়া হয় না।
            </p>
          </div>
          <div className="bg-card rounded-lg border p-6">
            <h3 className="font-bold mb-2">টেকনিক্যাল সাপোর্ট পাব?</h3>
            <p className="text-muted-foreground">
              হ্যাঁ, সকল প্রোডাক্টের জন্য আমরা ২৪/৭ টেকনিক্যাল সাপোর্ট প্রদান করি। আপনি ইমেইল বা লাইভ চ্যাটের মাধ্যমে আমাদের সাথে যোগাযোগ করতে
              পারেন।
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
