"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { useCart } from "@/context/cart-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Separator } from "@/components/ui/separator"
import { ShieldCheck, CheckCircle2, ArrowLeft, ArrowRight, Loader2, Phone } from "lucide-react"
import Image from "next/image"
import { motion } from "framer-motion"
import { processPayment } from "@/lib/payment-actions"
import PaymentConfirmation from "@/components/payment/payment-confirmation"

export default function CheckoutPage() {
  const { cart, clearCart } = useCart()
  const router = useRouter()
  const [paymentMethod, setPaymentMethod] = useState("bkash")
  const [phoneNumber, setPhoneNumber] = useState("")
  const [transactionId, setTransactionId] = useState("")
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [phone, setPhone] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const [paymentStep, setPaymentStep] = useState(1)
  const [showConfirmation, setShowConfirmation] = useState(false)
  const [confirmationData, setConfirmationData] = useState(null)
  const [formErrors, setFormErrors] = useState({
    name: false,
    email: false,
    phone: false,
    phoneNumber: false,
    transactionId: false,
  })

  const subtotal = cart.reduce((total, item) => {
    const itemPrice = item.discount ? item.price - (item.price * item.discount) / 100 : item.price
    return total + itemPrice * item.quantity
  }, 0)

  const discount = 0
  const total = subtotal - discount

  const validateStep1 = () => {
    const errors = {
      name: !name.trim(),
      email: !email.trim() || !/^\S+@\S+\.\S+$/.test(email),
      phone: !phone.trim() || phone.length < 11,
    }

    setFormErrors({ ...formErrors, ...errors })
    return !Object.values(errors).some((error) => error)
  }

  const validateStep2 = () => {
    const errors = {
      phoneNumber: !phoneNumber.trim() || phoneNumber.length < 11,
      transactionId: !transactionId.trim() || transactionId.length < 5,
    }

    setFormErrors({ ...formErrors, ...errors })
    return !Object.values(errors).some((error) => error)
  }

  const handleNextStep = () => {
    if (paymentStep === 1 && validateStep1()) {
      setPaymentStep(2)
    }
  }

  const handlePreviousStep = () => {
    if (paymentStep === 2) {
      setPaymentStep(1)
    }
  }

  const handleSubmitPayment = async (e) => {
    e.preventDefault()

    if (!validateStep2()) return

    setIsProcessing(true)

    try {
      // In a real app, this would communicate with your payment gateway
      const result = await processPayment({
        paymentMethod,
        amount: total,
        customerName: name,
        customerEmail: email,
        customerPhone: phone,
        paymentPhone: phoneNumber,
        transactionId,
        items: cart.map((item) => ({
          id: item.id,
          name: item.name,
          price: item.discount ? item.price - (item.price * item.discount) / 100 : item.price,
          quantity: item.quantity,
        })),
      })

      // Set confirmation data
      setConfirmationData({
        orderId: `ORD-${Date.now()}`,
        paymentMethod,
        amount: total,
        transactionId,
        date: new Date().toLocaleString("bn-BD"),
        items: cart,
      })

      setShowConfirmation(true)
      clearCart()
    } catch (error) {
      console.error("Payment processing error:", error)
      // Handle payment error
    } finally {
      setIsProcessing(false)
    }
  }

  if (showConfirmation && confirmationData) {
    return <PaymentConfirmation data={confirmationData} />
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.h1
        className="text-3xl font-bold mb-6"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        চেকআউট
      </motion.h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <motion.div
          className="lg:col-span-2"
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <div className="space-y-8">
            {/* Payment Steps */}
            <div className="flex justify-between mb-8">
              <motion.div
                className={`flex flex-col items-center ${paymentStep >= 1 ? "text-primary" : "text-muted-foreground"}`}
                whileHover={{ scale: 1.05 }}
              >
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center ${paymentStep >= 1 ? "bg-primary text-white" : "bg-muted"}`}
                >
                  1
                </div>
                <span className="text-sm mt-2">তথ্য</span>
              </motion.div>

              <div className={`flex-1 h-0.5 self-center mx-4 ${paymentStep >= 2 ? "bg-primary" : "bg-muted"}`}></div>

              <motion.div
                className={`flex flex-col items-center ${paymentStep >= 2 ? "text-primary" : "text-muted-foreground"}`}
                whileHover={{ scale: 1.05 }}
              >
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center ${paymentStep >= 2 ? "bg-primary text-white" : "bg-muted"}`}
                >
                  2
                </div>
                <span className="text-sm mt-2">পেমেন্ট</span>
              </motion.div>

              <div className={`flex-1 h-0.5 self-center mx-4 ${paymentStep >= 3 ? "bg-primary" : "bg-muted"}`}></div>

              <motion.div
                className={`flex flex-col items-center ${paymentStep >= 3 ? "text-primary" : "text-muted-foreground"}`}
                whileHover={{ scale: 1.05 }}
              >
                <div
                  className={`w-10 h-10 rounded-full flex items-center justify-center ${paymentStep >= 3 ? "bg-primary text-white" : "bg-muted"}`}
                >
                  3
                </div>
                <span className="text-sm mt-2">নিশ্চিতকরণ</span>
              </motion.div>
            </div>

            {paymentStep === 1 && (
              <motion.div
                className="rounded-lg border bg-card/30 backdrop-blur-md p-6 shadow-lg"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <h2 className="text-xl font-bold mb-4">কাস্টমার ইনফরমেশন</h2>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name" className={formErrors.name ? "text-red-500" : ""}>
                      নাম *
                    </Label>
                    <Input
                      id="name"
                      placeholder="আপনার নাম"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className={formErrors.name ? "border-red-500" : ""}
                    />
                    {formErrors.name && <p className="text-red-500 text-xs">নাম দিতে হবে</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email" className={formErrors.email ? "text-red-500" : ""}>
                      ইমেইল *
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="আপনার ইমেইল"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className={formErrors.email ? "border-red-500" : ""}
                    />
                    {formErrors.email && <p className="text-red-500 text-xs">সঠিক ইমেইল দিতে হবে</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone" className={formErrors.phone ? "text-red-500" : ""}>
                      ফোন নম্বর *
                    </Label>
                    <Input
                      id="phone"
                      placeholder="আপনার ফোন নম্বর"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className={formErrors.phone ? "border-red-500" : ""}
                    />
                    {formErrors.phone && <p className="text-red-500 text-xs">সঠিক ফোন নম্বর দিতে হবে</p>}
                  </div>
                </div>

                <motion.div className="mt-6" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                  <Button
                    onClick={handleNextStep}
                    className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                  >
                    পরবর্তী ধাপ
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </motion.div>
              </motion.div>
            )}

            {paymentStep === 2 && (
              <motion.div
                className="rounded-lg border bg-card/30 backdrop-blur-md p-6 shadow-lg"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <h2 className="text-xl font-bold mb-4">পেমেন্ট মেথড</h2>

                <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod} className="space-y-4">
                  <motion.div
                    className={`flex items-center space-x-2 rounded-lg border p-4 cursor-pointer hover:bg-accent ${paymentMethod === "bkash" ? "border-primary" : ""}`}
                    whileHover={{ scale: 1.02 }}
                  >
                    <RadioGroupItem value="bkash" id="bkash" />
                    <Label htmlFor="bkash" className="flex items-center gap-2 cursor-pointer">
                      <div className="relative w-8 h-8">
                        <Image src="/placeholder.svg?height=32&width=32" alt="bKash" fill className="object-contain" />
                      </div>
                      <span>বিকাশ</span>
                    </Label>
                  </motion.div>

                  <motion.div
                    className={`flex items-center space-x-2 rounded-lg border p-4 cursor-pointer hover:bg-accent ${paymentMethod === "nagad" ? "border-primary" : ""}`}
                    whileHover={{ scale: 1.02 }}
                  >
                    <RadioGroupItem value="nagad" id="nagad" />
                    <Label htmlFor="nagad" className="flex items-center gap-2 cursor-pointer">
                      <div className="relative w-8 h-8">
                        <Image src="/placeholder.svg?height=32&width=32" alt="Nagad" fill className="object-contain" />
                      </div>
                      <span>নগদ</span>
                    </Label>
                  </motion.div>

                  <motion.div
                    className={`flex items-center space-x-2 rounded-lg border p-4 cursor-pointer hover:bg-accent ${paymentMethod === "rocket" ? "border-primary" : ""}`}
                    whileHover={{ scale: 1.02 }}
                  >
                    <RadioGroupItem value="rocket" id="rocket" />
                    <Label htmlFor="rocket" className="flex items-center gap-2 cursor-pointer">
                      <div className="relative w-8 h-8">
                        <Image src="/placeholder.svg?height=32&width=32" alt="Rocket" fill className="object-contain" />
                      </div>
                      <span>রকেট</span>
                    </Label>
                  </motion.div>
                </RadioGroup>

                <div className="mt-6 p-4 bg-primary/5 rounded-lg border border-primary/20">
                  <div className="flex items-center gap-2 mb-3">
                    <Phone className="h-5 w-5 text-primary" />
                    <h3 className="font-medium">পেমেন্ট নির্দেশনা</h3>
                  </div>

                  <ol className="list-decimal list-inside space-y-2 text-sm">
                    <li>
                      আপনার {paymentMethod === "bkash" ? "বিকাশ" : paymentMethod === "nagad" ? "নগদ" : "রকেট"} অ্যাপ ওপেন
                      করুন
                    </li>
                    <li>
                      <span className="font-medium">০১৮৯৩১৫৪৫০৭</span> নম্বরে "সেন্ড মানি" অপশন সিলেক্ট করে {total} টাকা পাঠান
                    </li>
                    <li>ট্রানজেকশন আইডি কপি করুন</li>
                    <li>নিচের ফর্মে আপনার ফোন নম্বর এবং ট্রানজেকশন আইডি দিন</li>
                  </ol>
                </div>

                <div className="mt-6 space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="payment-phone" className={formErrors.phoneNumber ? "text-red-500" : ""}>
                      আপনার {paymentMethod} নম্বর *
                    </Label>
                    <Input
                      id="payment-phone"
                      placeholder={`যে ${paymentMethod} নম্বর থেকে পেমেন্ট করেছেন`}
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      className={formErrors.phoneNumber ? "border-red-500" : ""}
                    />
                    {formErrors.phoneNumber && <p className="text-red-500 text-xs">সঠিক ফোন নম্বর দিতে হবে</p>}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="transaction-id" className={formErrors.transactionId ? "text-red-500" : ""}>
                      ট্রানজেকশন আইডি *
                    </Label>
                    <Input
                      id="transaction-id"
                      placeholder="ট্রানজেকশন আইডি দিন"
                      value={transactionId}
                      onChange={(e) => setTransactionId(e.target.value)}
                      className={formErrors.transactionId ? "border-red-500" : ""}
                    />
                    {formErrors.transactionId && <p className="text-red-500 text-xs">ট্রানজেকশন আইডি দিতে হবে</p>}
                  </div>
                </div>

                <div className="mt-6 flex gap-3">
                  <motion.div className="flex-1" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                    <Button variant="outline" onClick={handlePreviousStep} className="w-full">
                      <ArrowLeft className="mr-2 h-4 w-4" />
                      আগের ধাপে ফিরুন
                    </Button>
                  </motion.div>

                  <motion.div className="flex-1" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                    <Button
                      onClick={handleSubmitPayment}
                      disabled={isProcessing}
                      className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                    >
                      {isProcessing ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          প্রসেসিং...
                        </>
                      ) : (
                        <>
                          <CheckCircle2 className="mr-2 h-4 w-4" />
                          পেমেন্ট নিশ্চিত করুন
                        </>
                      )}
                    </Button>
                  </motion.div>
                </div>
              </motion.div>
            )}
          </div>
        </motion.div>

        <motion.div
          className="lg:col-span-1"
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.4 }}
        >
          <div className="rounded-lg border bg-card/30 backdrop-blur-md p-6 sticky top-4 shadow-lg overflow-hidden">
            {/* Glass effect overlay */}
            <div className="absolute inset-0 bg-gradient-to-br from-purple-500/5 to-blue-500/5"></div>

            <div className="relative z-10">
              <h2 className="font-bold text-lg mb-4">অর্ডার সামারি</h2>

              <div className="space-y-4 mb-4">
                {cart.map((item) => {
                  const itemPrice = item.discount ? item.price - (item.price * item.discount) / 100 : item.price

                  return (
                    <motion.div
                      key={item.id}
                      className="flex justify-between"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.3 }}
                      whileHover={{ scale: 1.02 }}
                    >
                      <div className="flex items-center gap-2">
                        <div className="relative w-10 h-10 rounded-md overflow-hidden bg-muted">
                          <Image src={item.image || "/placeholder.svg"} alt={item.name} fill className="object-cover" />
                        </div>
                        <div>
                          <div className="font-medium">{item.name}</div>
                          <div className="text-sm text-muted-foreground">x{item.quantity}</div>
                        </div>
                      </div>
                      <div className="font-medium">৳{itemPrice * item.quantity}</div>
                    </motion.div>
                  )
                })}
              </div>

              <Separator className="my-4" />

              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">সাবটোটাল</span>
                  <span>৳{subtotal}</span>
                </div>

                <div className="flex justify-between">
                  <span className="text-muted-foreground">ডিসকাউন্ট</span>
                  <span>৳{discount}</span>
                </div>

                <motion.div className="border-t pt-2 mt-2 flex justify-between font-bold" whileHover={{ scale: 1.03 }}>
                  <span>মোট</span>
                  <span className="text-primary">৳{total}</span>
                </motion.div>
              </div>

              <div className="mt-6 flex items-center justify-center text-sm text-muted-foreground">
                <ShieldCheck className="mr-2 h-4 w-4" />
                সিকিউর পেমেন্ট
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  )
}
