"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import type { Product } from "@/types/product"
import { useToast } from "@/components/ui/use-toast"
import { useRouter } from "next/navigation"

export interface CartItem extends Product {
  quantity: number
}

interface CartContextType {
  cart: CartItem[]
  addToCart: (product: Product, quantity?: number, redirectToCheckout?: boolean) => void
  removeFromCart: (productId: string) => void
  updateQuantity: (productId: string, quantity: number) => void
  clearCart: () => void
}

const CartContext = createContext<CartContextType | undefined>(undefined)

export function CartProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartItem[]>([])
  const { toast } = useToast()
  const router = useRouter()

  // Load cart from localStorage on initial render
  useEffect(() => {
    const savedCart = localStorage.getItem("cart")
    if (savedCart) {
      try {
        setCart(JSON.parse(savedCart))
      } catch (error) {
        console.error("Failed to parse cart from localStorage:", error)
      }
    }
  }, [])

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cart))
  }, [cart])

  const addToCart = (product: Product, quantity = 1, redirectToCheckout = false) => {
    setCart((prevCart) => {
      const existingItem = prevCart.find((item) => item.id === product.id)

      let updatedCart

      if (existingItem) {
        // Update quantity if item already exists
        updatedCart = prevCart.map((item) =>
          item.id === product.id ? { ...item, quantity: item.quantity + quantity } : item,
        )

        toast({
          title: "কার্ট আপডেট করা হয়েছে",
          description: `${product.name} এর পরিমাণ আপডেট করা হয়েছে।`,
        })
      } else {
        // Add new item
        updatedCart = [...prevCart, { ...product, quantity }]

        toast({
          title: "কার্টে যোগ করা হয়েছে",
          description: `${product.name} কার্টে যোগ করা হয়েছে।`,
        })
      }

      // If redirectToCheckout is true, redirect to checkout page
      if (redirectToCheckout) {
        setTimeout(() => {
          router.push("/checkout")
        }, 500)
      }

      return updatedCart
    })
  }

  const removeFromCart = (productId: string) => {
    setCart((prevCart) => {
      const updatedCart = prevCart.filter((item) => item.id !== productId)

      toast({
        title: "কার্ট থেকে সরানো হয়েছে",
        description: "প্রোডাক্টটি কার্ট থেকে সরানো হয়েছে।",
      })

      return updatedCart
    })
  }

  const updateQuantity = (productId: string, quantity: number) => {
    setCart((prevCart) => prevCart.map((item) => (item.id === productId ? { ...item, quantity } : item)))
  }

  const clearCart = () => {
    setCart([])
    toast({
      title: "কার্ট খালি করা হয়েছে",
      description: "আপনার কার্ট খালি করা হয়েছে।",
    })
  }

  return (
    <CartContext.Provider value={{ cart, addToCart, removeFromCart, updateQuantity, clearCart }}>
      {children}
    </CartContext.Provider>
  )
}

export function useCart() {
  const context = useContext(CartContext)
  if (context === undefined) {
    throw new Error("useCart must be used within a CartProvider")
  }
  return context
}
