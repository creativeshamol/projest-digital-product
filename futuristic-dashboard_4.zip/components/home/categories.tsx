import Link from "next/link"
import { Code, FileCode, BookOpen, Layers, Palette, Music, Video, Lightbulb } from "lucide-react"

const categories = [
  {
    id: "software",
    name: "সফটওয়্যার",
    icon: Code,
    color: "bg-blue-100 text-blue-600",
    link: "/products?category=software",
  },
  {
    id: "template",
    name: "টেমপ্লেট",
    icon: FileCode,
    color: "bg-purple-100 text-purple-600",
    link: "/products?category=template",
  },
  {
    id: "ebook",
    name: "ই-বুক",
    icon: BookOpen,
    color: "bg-green-100 text-green-600",
    link: "/products?category=ebook",
  },
  {
    id: "course",
    name: "কোর্স",
    icon: Lightbulb,
    color: "bg-amber-100 text-amber-600",
    link: "/products?category=course",
  },
  {
    id: "graphics",
    name: "গ্রাফিক্স",
    icon: Palette,
    color: "bg-pink-100 text-pink-600",
    link: "/products?category=graphics",
  },
  {
    id: "ui-kit",
    name: "ইউআই কিট",
    icon: Layers,
    color: "bg-cyan-100 text-cyan-600",
    link: "/products?category=ui-kit",
  },
  {
    id: "audio",
    name: "অডিও",
    icon: Music,
    color: "bg-red-100 text-red-600",
    link: "/products?category=audio",
  },
  {
    id: "video",
    name: "ভিডিও",
    icon: Video,
    color: "bg-indigo-100 text-indigo-600",
    link: "/products?category=video",
  },
]

export default function Categories() {
  return (
    <div className="my-12">
      <div className="flex flex-col items-center mb-8">
        <h2 className="text-3xl font-bold mb-2">ক্যাটাগরি</h2>
        <p className="text-muted-foreground text-center max-w-2xl">
          আমাদের বিভিন্ন ক্যাটাগরির প্রোডাক্ট দেখুন এবং আপনার প্রয়োজন অনুযায়ী প্রোডাক্ট কিনুন।
        </p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-8 gap-4">
        {categories.map((category) => (
          <Link
            key={category.id}
            href={category.link}
            className="flex flex-col items-center justify-center p-4 rounded-lg border hover:border-primary hover:shadow-sm transition-all"
          >
            <div className={`p-3 rounded-full ${category.color} mb-3`}>
              <category.icon size={24} />
            </div>
            <span className="text-sm font-medium text-center">{category.name}</span>
          </Link>
        ))}
      </div>
    </div>
  )
}
