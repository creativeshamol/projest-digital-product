"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

const slides = [
  {
    id: 1,
    title: "প্রিমিয়াম ডিজিটাল প্রোডাক্ট",
    description: "বাংলাদেশের সেরা ডিজিটাল প্রোডাক্ট মার্কেটপ্লেস। সফটওয়্যার, টেমপ্লেট, ই-বুক এবং আরও অনেক কিছু।",
    image: "/placeholder.svg?height=600&width=1200",
    cta: "প্রোডাক্ট দেখুন",
    link: "/products",
  },
  {
    id: 2,
    title: "স্পেশাল অফার",
    description: "সীমিত সময়ের জন্য সকল প্রোডাক্টে ৩০% পর্যন্ত ছাড়। আজই কিনুন এবং সাশ্রয় করুন।",
    image: "/placeholder.svg?height=600&width=1200",
    cta: "অফার দেখুন",
    link: "/products?discount=true",
  },
  {
    id: 3,
    title: "নতুন ই-লার্নিং কোর্স",
    description: "আমাদের নতুন ই-লার্নিং কোর্সগুলো দেখুন। ডিজিটাল মার্কেটিং, ওয়েব ডেভেলপমেন্ট, গ্রাফিক ডিজাইন এবং আরও অনেক কিছু।",
    image: "/placeholder.svg?height=600&width=1200",
    cta: "কোর্স দেখুন",
    link: "/products?category=course",
  },
]

export default function HeroSection() {
  const [currentSlide, setCurrentSlide] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length)
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="relative overflow-hidden rounded-lg mt-6 mb-12">
      <div
        className="flex transition-transform duration-500 ease-in-out"
        style={{ transform: `translateX(-${currentSlide * 100}%)` }}
      >
        {slides.map((slide) => (
          <div key={slide.id} className="w-full flex-shrink-0 relative">
            <div className="aspect-[21/9] md:aspect-[3/1] relative">
              <Image src={slide.image || "/placeholder.svg"} alt={slide.title} fill className="object-cover" />
              <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-black/20" />

              <div className="absolute inset-0 flex items-center">
                <div className="container mx-auto px-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
                    <div className="md:col-span-1">
                      <div className="max-w-lg text-white">
                        <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">{slide.title}</h1>
                        <p className="text-lg md:text-xl mb-6 text-white/90">{slide.description}</p>
                        <Button asChild size="lg" className="gap-2">
                          <Link href={slide.link}>
                            {slide.cta}
                            <ArrowRight size={16} />
                          </Link>
                        </Button>
                      </div>
                    </div>
                    <div className="hidden md:flex md:col-span-2 gap-4 justify-end">
                      <div className="relative w-1/3 aspect-[3/4] rounded-lg overflow-hidden transform rotate-[-5deg] hover:rotate-0 transition-transform duration-300 shadow-xl">
                        <Image
                          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Leonardo_Phoenix_10_Slider_1_LimitedTime_Offer_BanglaEnglishVi_0.jpg-jFkQecvdihNGgl9jzWTLmiz9ofOia9.jpeg"
                          alt="সীমিত সময়ের অফার"
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div className="relative w-1/3 aspect-[3/4] rounded-lg overflow-hidden transform translate-y-4 hover:translate-y-0 transition-transform duration-300 shadow-xl z-10">
                        <Image
                          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Leonardo_Phoenix_10_Slider_1_LimitedTime_Offer_BanglaEnglishVi_1.jpg-BLcl8SqRV8wX3XLeNHDHRgpYDHmajr.jpeg"
                          alt="ডিজিটাল প্রোডাক্ট অফার"
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div className="relative w-1/3 aspect-[3/4] rounded-lg overflow-hidden transform rotate-[5deg] hover:rotate-0 transition-transform duration-300 shadow-xl">
                        <Image
                          src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Leonardo_Phoenix_10_Slider_1_LimitedTime_Offer_BanglaEnglishVi_3.jpg-n0WX9hLFaDVCCx28MyVi5I8vtp27KV.jpeg"
                          alt="৩০% ছাড় অফার"
                          fill
                          className="object-cover"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
        {slides.map((_, index) => (
          <button
            key={index}
            className={`h-2 rounded-full transition-all ${
              currentSlide === index ? "w-8 bg-primary" : "w-2 bg-white/50"
            }`}
            onClick={() => setCurrentSlide(index)}
          />
        ))}
      </div>
    </div>
  )
}
