"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight, Star } from "lucide-react"

const testimonials = [
  {
    id: 1,
    name: "করিম আহমেদ",
    role: "ওয়েব ডেভেলপার",
    avatar: "/placeholder.svg?height=80&width=80",
    content:
      "আমি এই ওয়েবসাইট থেকে বেশ কয়েকটি ওয়েব টেমপ্লেট কিনেছি। প্রোডাক্টের মান খুবই ভালো এবং কাস্টমার সাপোর্ট অসাধারণ। আমি সবাইকে এই ওয়েবসাইট থেকে প্রোডাক্ট কেনার পরামর্শ দিব।",
    rating: 5,
  },
  {
    id: 2,
    name: "ফাতেমা খাতুন",
    role: "ডিজিটাল মার্কেটার",
    avatar: "/placeholder.svg?height=80&width=80",
    content:
      "আমি এখান থেকে ডিজিটাল মার্কেটিং সম্পর্কিত কয়েকটি ই-বুক কিনেছি। বইগুলো খুবই ইনফরমেটিভ এবং আমার ব্যবসা বৃদ্ধিতে সাহায্য করেছে। ধন্যবাদ ডিজিটালপ্রোডাক্ট টিমকে।",
    rating: 4,
  },
  {
    id: 3,
    name: "রাকিব হাসান",
    role: "গ্রাফিক ডিজাইনার",
    avatar: "/placeholder.svg?height=80&width=80",
    content:
      "আমি একজন গ্রাফিক ডিজাইনার এবং এখান থেকে বেশ কয়েকটি ডিজাইন টেমপ্লেট কিনেছি। প্রোডাক্টের মান এবং ডিজাইন খুবই আধুনিক। আমি খুবই সন্তুষ্ট এবং আবারও কিনব।",
    rating: 5,
  },
  {
    id: 4,
    name: "নাজমুল হক",
    role: "ফ্রিল্যান্সার",
    avatar: "/placeholder.svg?height=80&width=80",
    content:
      "আমি একজন ফ্রিল্যান্সার এবং এখান থেকে বেশ কয়েকটি সফটওয়্যার কিনেছি। প্রোডাক্টগুলো আমার কাজকে অনেক সহজ করে দিয়েছে। দাম তুলনামূলকভাবে কম এবং মান খুবই ভালো।",
    rating: 5,
  },
  {
    id: 5,
    name: "সাবরিনা আক্তার",
    role: "কন্টেন্ট রাইটার",
    avatar: "/placeholder.svg?height=80&width=80",
    content:
      "আমি এখান থেকে কন্টেন্ট রাইটিং সম্পর্কিত একটি কোর্স কিনেছি। কোর্সের কন্টেন্ট খুবই ভালো এবং ইনস্ট্রাক্টর খুবই দক্ষ। আমি এই কোর্স থেকে অনেক কিছু শিখেছি।",
    rating: 4,
  },
]

export default function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [visibleCount, setVisibleCount] = useState(3)

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth < 768) {
        setVisibleCount(1)
      } else if (window.innerWidth < 1024) {
        setVisibleCount(2)
      } else {
        setVisibleCount(3)
      }
    }

    handleResize()
    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  const nextSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex + 1) % (testimonials.length - visibleCount + 1))
  }

  const prevSlide = () => {
    setCurrentIndex((prevIndex) => (prevIndex === 0 ? testimonials.length - visibleCount : prevIndex - 1))
  }

  return (
    <div className="my-16">
      <div className="flex flex-col items-center mb-8">
        <h2 className="text-3xl font-bold mb-2">গ্রাহকদের মতামত</h2>
        <p className="text-muted-foreground text-center max-w-2xl">
          আমাদের সন্তুষ্ট গ্রাহকদের মতামত দেখুন। তারা আমাদের প্রোডাক্ট এবং সার্ভিস সম্পর্কে কী বলেছেন।
        </p>
      </div>

      <div className="relative">
        <div className="overflow-hidden">
          <div
            className="flex transition-transform duration-300 ease-in-out"
            style={{ transform: `translateX(-${currentIndex * (100 / visibleCount)}%)` }}
          >
            {testimonials.map((testimonial) => (
              <div key={testimonial.id} className="px-3" style={{ width: `${100 / visibleCount}%` }}>
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center mb-4">
                      <div className="relative w-12 h-12 rounded-full overflow-hidden mr-4">
                        <Image
                          src={testimonial.avatar || "/placeholder.svg"}
                          alt={testimonial.name}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div>
                        <h4 className="font-bold">{testimonial.name}</h4>
                        <p className="text-sm text-muted-foreground">{testimonial.role}</p>
                      </div>
                    </div>

                    <div className="flex mb-4">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          size={16}
                          className={i < testimonial.rating ? "text-yellow-500 fill-yellow-500" : "text-gray-300"}
                        />
                      ))}
                    </div>

                    <p className="text-muted-foreground">"{testimonial.content}"</p>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        </div>

        <Button
          variant="outline"
          size="icon"
          className="absolute top-1/2 -left-4 transform -translate-y-1/2 rounded-full"
          onClick={prevSlide}
        >
          <ChevronLeft size={16} />
        </Button>

        <Button
          variant="outline"
          size="icon"
          className="absolute top-1/2 -right-4 transform -translate-y-1/2 rounded-full"
          onClick={nextSlide}
        >
          <ChevronRight size={16} />
        </Button>
      </div>
    </div>
  )
}
