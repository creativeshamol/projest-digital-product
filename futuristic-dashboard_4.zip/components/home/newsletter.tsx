"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Mail } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

export default function Newsletter() {
  const [email, setEmail] = useState("")
  const { toast } = useToast()

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!email) return

    // Here you would typically send this to your API
    toast({
      title: "সাবস্ক্রাইব করা হয়েছে!",
      description: "আপনি সফলভাবে আমাদের নিউজলেটারে সাবস্ক্রাইব করেছেন।",
    })

    setEmail("")
  }

  return (
    <div className="my-16 bg-primary/5 rounded-lg py-12 px-4">
      <div className="max-w-3xl mx-auto text-center">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-6">
          <Mail className="h-8 w-8 text-primary" />
        </div>

        <h2 className="text-3xl font-bold mb-4">আমাদের নিউজলেটারে সাবস্ক্রাইব করুন</h2>

        <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
          আমাদের নতুন প্রোডাক্ট, স্পেশাল অফার এবং ডিসকাউন্ট সম্পর্কে জানতে আমাদের নিউজলেটারে সাবস্ক্রাইব করুন।
        </p>

        <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-2 max-w-md mx-auto">
          <Input
            type="email"
            placeholder="আপনার ইমেইল"
            className="flex-1"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <Button type="submit">সাবস্ক্রাইব</Button>
        </form>

        <p className="text-xs text-muted-foreground mt-4">
          সাবস্ক্রাইব করার মাধ্যমে আপনি আমাদের{" "}
          <a href="/privacy-policy" className="underline">
            প্রাইভেসি পলিসি
          </a>{" "}
          মেনে নিচ্ছেন।
        </p>
      </div>
    </div>
  )
}
