"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ProductCard } from "@/components/product/product-card"
import { products } from "@/data/products"
import { ArrowRight, ChevronLeft, ChevronRight, Zap } from "lucide-react"

export default function FeaturedProducts() {
  // Get 4 featured products and 4 AI products
  const featuredProducts = products.filter((product) => product.featured).slice(0, 4)
  const aiProducts = products
    .filter((product) => product.category === "ai-tool" || product.category === "subscription")
    .slice(0, 4)

  // Promotional banners
  const promotionalBanners = [
    {
      id: 1,
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Leonardo_Phoenix_10_Slider_1_LimitedTime_Offer_BanglaEnglishVi_0.jpg-jFkQecvdihNGgl9jzWTLmiz9ofOia9.jpeg",
      alt: "সীমিত সময়ের অফার - ৩০% ছাড়",
      link: "/products?discount=30",
    },
    {
      id: 2,
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Leonardo_Phoenix_10_Slider_1_LimitedTime_Offer_BanglaEnglishVi_1.jpg-BLcl8SqRV8wX3XLeNHDHRgpYDHmajr.jpeg",
      alt: "ডিজিটাল প্রোডাক্ট লিমিটেড টাইম অফার",
      link: "/products?category=ebook&discount=30",
    },
    {
      id: 3,
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Leonardo_Phoenix_10_Slider_1_LimitedTime_Offer_BanglaEnglishVi_3.jpg-n0WX9hLFaDVCCx28MyVi5I8vtp27KV.jpeg",
      alt: "স্পেশাল অফার - ৩০% ছাড়",
      link: "/products?discount=30",
    },
  ]

  const [currentBanner, setCurrentBanner] = useState(0)

  // Auto-rotate banners
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentBanner((prev) => (prev + 1) % promotionalBanners.length)
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  const nextBanner = () => {
    setCurrentBanner((prev) => (prev + 1) % promotionalBanners.length)
  }

  const prevBanner = () => {
    setCurrentBanner((prev) => (prev === 0 ? promotionalBanners.length - 1 : prev - 1))
  }

  return (
    <div className="my-12">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
        <div>
          <h2 className="text-3xl font-bold mb-2">ফিচার্ড প্রোডাক্ট</h2>
          <p className="text-muted-foreground max-w-2xl">
            আমাদের সেরা এবং জনপ্রিয় প্রোডাক্টগুলো দেখুন। এই প্রোডাক্টগুলো আমাদের গ্রাহকদের দ্বারা সবচেয়ে বেশি পছন্দ করা হয়েছে।
          </p>
        </div>

        <Button asChild variant="outline" className="mt-4 md:mt-0 gap-2">
          <Link href="/products">
            সব প্রোডাক্ট দেখুন
            <ArrowRight size={16} />
          </Link>
        </Button>
      </div>

      {/* Promotional Banner Slider */}
      <div className="relative mb-10 rounded-xl overflow-hidden">
        <div className="aspect-[21/9] md:aspect-[3/1] relative">
          <div
            className="flex transition-transform duration-500 ease-in-out"
            style={{ transform: `translateX(-${currentBanner * 100}%)` }}
          >
            {promotionalBanners.map((banner) => (
              <div key={banner.id} className="w-full flex-shrink-0 relative">
                <Link href={banner.link}>
                  <div className="relative aspect-[21/9] md:aspect-[3/1] w-full">
                    <Image
                      src={banner.image || "/placeholder.svg"}
                      alt={banner.alt}
                      fill
                      className="object-cover"
                      priority
                    />
                  </div>
                </Link>
              </div>
            ))}
          </div>

          {/* Navigation buttons */}
          <button
            onClick={prevBanner}
            className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/30 hover:bg-black/50 text-white rounded-full p-2 backdrop-blur-sm transition-colors"
            aria-label="Previous banner"
          >
            <ChevronLeft size={24} />
          </button>

          <button
            onClick={nextBanner}
            className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/30 hover:bg-black/50 text-white rounded-full p-2 backdrop-blur-sm transition-colors"
            aria-label="Next banner"
          >
            <ChevronRight size={24} />
          </button>

          {/* Indicators */}
          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
            {promotionalBanners.map((_, index) => (
              <button
                key={index}
                className={`h-2 rounded-full transition-all ${
                  currentBanner === index ? "w-8 bg-white" : "w-2 bg-white/50"
                }`}
                onClick={() => setCurrentBanner(index)}
                aria-label={`Go to slide ${index + 1}`}
              />
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {featuredProducts.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>

      {/* AI Products Section */}
      <div className="mt-16">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
          <div>
            <h2 className="text-3xl font-bold mb-2 flex items-center">
              <Zap className="mr-2 text-yellow-500" />
              AI টুল এবং সাবস্ক্রিপশন
            </h2>
            <p className="text-muted-foreground max-w-2xl">
              আমাদের সর্বাধুনিক AI টুল এবং ডিজিটাল সাবস্ক্রিপশন দেখুন। এই প্রোডাক্টগুলো আপনার কাজকে আরও সহজ এবং দক্ষ করে তুলবে।
            </p>
          </div>

          <Button
            asChild
            className="mt-4 md:mt-0 gap-2 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
          >
            <Link href="/digital-products">
              সব AI টুল দেখুন
              <ArrowRight size={16} />
            </Link>
          </Button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {aiProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>
    </div>
  )
}
