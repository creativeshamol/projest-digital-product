import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Clock, ArrowRight } from "lucide-react"

export default function SpecialOffers() {
  return (
    <div className="my-16 bg-muted rounded-lg overflow-hidden">
      <div className="container mx-auto px-4 py-12">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-8 md:mb-0 md:pr-8">
            <Badge className="mb-4 bg-primary hover:bg-primary">স্পেশাল অফার</Badge>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">সীমিত সময়ের জন্য ৩০% ছাড়</h2>
            <p className="text-muted-foreground mb-6">
              আমাদের সকল প্রিমিয়াম প্রোডাক্টে ৩০% পর্যন্ত ছাড় পাচ্ছেন। এই অফার সীমিত সময়ের জন্য, তাই আজই কিনুন এবং সাশ্রয় করুন।
            </p>

            <div className="flex items-center mb-6">
              <Clock className="text-primary mr-2" />
              <span className="text-sm">
                অফার শেষ হতে আর <span className="font-bold">৩ দিন</span> বাকি
              </span>
            </div>

            <Button asChild size="lg" className="gap-2">
              <Link href="/products?discount=true">
                অফার দেখুন
                <ArrowRight size={16} />
              </Link>
            </Button>
          </div>

          <div className="md:w-1/2 relative">
            <div className="aspect-square md:aspect-[4/3] relative">
              <Image
                src="/placeholder.svg?height=400&width=600"
                alt="Special Offer"
                fill
                className="object-cover rounded-lg"
              />

              <div className="absolute top-4 right-4 bg-red-500 text-white text-lg font-bold rounded-full w-16 h-16 flex items-center justify-center transform rotate-12">
                -30%
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
