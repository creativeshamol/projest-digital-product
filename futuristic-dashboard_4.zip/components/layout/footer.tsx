import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Facebook, Twitter, Instagram, Youtube, Mail, Phone, MapPin } from "lucide-react"

export default function Footer() {
  return (
    <footer className="bg-muted mt-16">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-bold mb-4">
              ডিজিটাল<span className="text-primary">প্রোডাক্ট</span>
            </h3>
            <p className="text-muted-foreground mb-4">
              বাংলাদেশের অন্যতম সেরা ডিজিটাল প্রোডাক্ট মার্কেটপ্লেস। আমরা উচ্চমানের ডিজিটাল প্রোডাক্ট সরবরাহ করি।
            </p>
            <div className="flex space-x-3">
              <Button variant="ghost" size="icon" className="h-9 w-9 rounded-full">
                <Facebook size={18} />
              </Button>
              <Button variant="ghost" size="icon" className="h-9 w-9 rounded-full">
                <Twitter size={18} />
              </Button>
              <Button variant="ghost" size="icon" className="h-9 w-9 rounded-full">
                <Instagram size={18} />
              </Button>
              <Button variant="ghost" size="icon" className="h-9 w-9 rounded-full">
                <Youtube size={18} />
              </Button>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">কুইক লিংক</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/about" className="text-muted-foreground hover:text-foreground">
                  আমাদের সম্পর্কে
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-muted-foreground hover:text-foreground">
                  যোগাযোগ
                </Link>
              </li>
              <li>
                <Link href="/faq" className="text-muted-foreground hover:text-foreground">
                  সাধারণ জিজ্ঞাসা
                </Link>
              </li>
              <li>
                <Link href="/privacy-policy" className="text-muted-foreground hover:text-foreground">
                  প্রাইভেসি পলিসি
                </Link>
              </li>
              <li>
                <Link href="/terms" className="text-muted-foreground hover:text-foreground">
                  শর্তাবলী
                </Link>
              </li>
              <li>
                <Link href="/refund-policy" className="text-muted-foreground hover:text-foreground">
                  রিফান্ড পলিসি
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">ক্যাটাগরি</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/products?category=software" className="text-muted-foreground hover:text-foreground">
                  সফটওয়্যার
                </Link>
              </li>
              <li>
                <Link href="/products?category=template" className="text-muted-foreground hover:text-foreground">
                  টেমপ্লেট
                </Link>
              </li>
              <li>
                <Link href="/products?category=ebook" className="text-muted-foreground hover:text-foreground">
                  ই-বুক
                </Link>
              </li>
              <li>
                <Link href="/products?category=course" className="text-muted-foreground hover:text-foreground">
                  কোর্স
                </Link>
              </li>
              <li>
                <Link href="/products?category=graphics" className="text-muted-foreground hover:text-foreground">
                  গ্রাফিক্স
                </Link>
              </li>
              <li>
                <Link href="/products?category=audio" className="text-muted-foreground hover:text-foreground">
                  অডিও
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-4">যোগাযোগ</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <MapPin size={18} className="mr-2 mt-0.5 text-primary" />
                <span className="text-muted-foreground">১২৩ ডিজিটাল টাওয়ার, গুলশান-১, ঢাকা-১২১২, বাংলাদেশ</span>
              </li>
              <li className="flex items-center">
                <Phone size={18} className="mr-2 text-primary" />
                <span className="text-muted-foreground">+880 1893154507</span>
              </li>
              <li className="flex items-center">
                <Mail size={18} className="mr-2 text-primary" />
                <span className="text-muted-foreground">creativeshamol75@gmail.com</span>
              </li>
            </ul>

            <div className="mt-4">
              <h4 className="text-sm font-medium mb-2">নিউজলেটার সাবস্ক্রাইব করুন</h4>
              <div className="flex">
                <Input placeholder="আপনার ইমেইল" className="rounded-r-none" />
                <Button className="rounded-l-none">সাবস্ক্রাইব</Button>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t mt-12 pt-6 text-center text-muted-foreground">
          <p>&copy; {new Date().getFullYear()} ডিজিটালপ্রোডাক্ট। সর্বস্বত্ব সংরক্ষিত।</p>
        </div>
      </div>
    </footer>
  )
}
