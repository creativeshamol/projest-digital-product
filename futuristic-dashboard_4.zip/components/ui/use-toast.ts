"use client"

import * as React from "react"
import * as ToastPrimitives from "@radix-ui/react-toast"

import { cn } from "@/lib/utils"

const ToastProvider = ToastPrimitives.Provider

const ToastViewport = React.forwardRef<
  React.ElementRef<typeof ToastPrimitives.Viewport>,
  React.ComponentPropsWithoutRef<typeof ToastPrimitives.Viewport>
>(({ className, ...props }, ref) => {
  return (
    <ToastPrimitives.Viewport
      ref={ref}
      className={cn(
        "fixed bottom-0 right-0 z-[100] flex max-h-screen w-full flex-col gap-2 p-4 sm:w-[400px]",
        className,
      )}
      {...props}
    />
  )
})
ToastViewport.displayName = ToastPrimitives.Viewport.displayName

const Toast = React.forwardRef<
  React.ElementRef<typeof ToastPrimitives.Root>,
  React.ComponentPropsWithoutRef<typeof ToastPrimitives.Root>
>(({ className, ...props }, ref) => {
  return (
    <ToastPrimitives.Root
      ref={ref}
      className={cn(
        "group relative flex w-full items-center justify-between space-x-4 overflow-hidden rounded-md border p-4 pr-5 shadow-lg transition-all data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-80 data-[state=closed]:zoom-out-95 data-[side=top]:translate-y-0 data-[side=bottom]:translate-y-0 data-[side=right]:translate-x-0 data-[side=left]:translate-x-0",
        className,
      )}
      {...props}
    />
  )
})
Toast.displayName = ToastPrimitives.Root.displayName

const ToastTrigger = ToastPrimitives.Trigger

const ToastClose = React.forwardRef<
  React.ElementRef<typeof ToastPrimitives.Close>,
  React.ComponentPropsWithoutRef<typeof ToastPrimitives.Close>
>(({ className, ...props }, ref) => {
  return (
    <ToastPrimitives.Close
      ref={ref}
      className={cn(
        "absolute right-2 top-2 rounded-md text-gray-400 opacity-0 transition-opacity hover:text-gray-500 focus:shadow-none focus:outline-none group-hover:opacity-100",
        className,
      )}
      {...props}
    />
  )
})
ToastClose.displayName = ToastPrimitives.Close.displayName

const ToastTitle = React.forwardRef<
  React.ElementRef<typeof ToastPrimitives.Title>,
  React.ComponentPropsWithoutRef<typeof ToastPrimitives.Title>
>(({ className, ...props }, ref) => {
  return (
    <ToastPrimitives.Title ref={ref} className={cn("text-sm font-semibold [&+div]:text-xs", className)} {...props} />
  )
})
ToastTitle.displayName = ToastPrimitives.Title.displayName

const ToastDescription = React.forwardRef<
  React.ElementRef<typeof ToastPrimitives.Description>,
  React.ComponentPropsWithoutRef<typeof ToastPrimitives.Description>
>(({ className, ...props }, ref) => {
  return <ToastPrimitives.Description ref={ref} className={cn("text-sm text-gray-500", className)} {...props} />
})
ToastDescription.displayName = ToastPrimitives.Description.displayName

type ToastActionProps = React.ComponentPropsWithoutRef<typeof ToastPrimitives.Action>

const ToastAction = React.forwardRef<React.ElementRef<typeof ToastPrimitives.Action>, ToastActionProps>(
  ({ className, ...props }, ref) => {
    return (
      <ToastPrimitives.Action
        ref={ref}
        className={cn(
          "inline-flex h-8 items-center justify-center rounded-md bg-transparent px-3 text-sm font-medium transition-colors focus:shadow-sm focus:outline-none",
          className,
        )}
        {...props}
      />
    )
  },
)
ToastAction.displayName = ToastPrimitives.Action.displayName

type UseToastProps = (props?: {
  id?: string
  title?: React.ReactNode
  description?: React.ReactNode
  action?: React.ReactNode
  duration?: number
  onOpenChange?: (open: boolean) => void
}) => void

interface Toast {
  id: string
  title?: React.ReactNode
  description?: React.ReactNode
  action?: React.ReactNode
  duration?: number
  onOpenChange?: (open: boolean) => void
}

interface ToastContextProps {
  toasts: Toast[]
  toast: UseToastProps
  dismiss: (toastId: string) => void
}

const ToastContext = React.createContext<ToastContextProps>({
  toasts: [],
  toast: () => {},
  dismiss: () => {},
})

function useToast() {
  return React.useContext(ToastContext)
}

function Toaster() {
  const [toasts, setToasts] = React.useState<Toast[]>([])

  const toast: UseToastProps = React.useCallback(
    ({ ...props }) => {
      const id = String(Math.random())
      setToasts([...toasts, { id, ...props }])
    },
    [toasts],
  )

  const dismiss = React.useCallback(
    (toastId: string) => {
      setToasts(toasts.filter((toast) => toast.id !== toastId))
    },
    [toasts],
  )

  return (
    <ToastContext.Provider value={{ toasts, toast, dismiss }}>
      <ToastProvider>
        {toasts.map((toast) => (
          <Toast key={toast.id} onOpenChange={toast.onOpenChange}>
            <ToastTitle>{toast.title}</ToastTitle>
            {toast.description && <ToastDescription>{toast.description}</ToastDescription>}
            <ToastClose />
          </Toast>
        ))}
        <ToastViewport />
      </ToastProvider>
    </ToastContext.Provider>
  )
}

export {
  Toaster,
  ToastProvider,
  ToastViewport,
  type Toast,
  ToastTrigger,
  ToastTitle,
  ToastDescription,
  ToastClose,
  ToastAction,
  useToast,
}

function cn(...inputs: any[]): string {
  let str = ""
  for (let i = 0; i < inputs.length; i++) {
    if (typeof inputs[i] === "string") {
      str += inputs[i] + " "
    }
  }
  return str.trim()
}
