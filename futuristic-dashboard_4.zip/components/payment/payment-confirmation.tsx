"use client"

import { useRef } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { motion } from "framer-motion"
import { Download, Home, ShoppingBag, CheckCircle } from "lucide-react"
import html2canvas from "html2canvas"

export default function PaymentConfirmation({ data }) {
  const router = useRouter()
  const confirmationRef = useRef(null)

  const downloadConfirmation = async () => {
    if (!confirmationRef.current) return

    try {
      const canvas = await html2canvas(confirmationRef.current, {
        scale: 2,
        backgroundColor: null,
        logging: false,
      })

      const image = canvas.toDataURL("image/png")
      const link = document.createElement("a")
      link.href = image
      link.download = `payment-confirmation-${data.orderId}.png`
      link.click()
    } catch (error) {
      console.error("Error generating confirmation image:", error)
    }
  }

  return (
    <div className="container mx-auto px-4 py-12 max-w-3xl">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="flex flex-col items-center justify-center mb-8"
      >
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.3, type: "spring", stiffness: 200 }}
          className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mb-4"
        >
          <CheckCircle className="h-10 w-10 text-green-600" />
        </motion.div>
        <h1 className="text-3xl font-bold text-center">পেমেন্ট সফল হয়েছে!</h1>
        <p className="text-muted-foreground text-center mt-2">আপনার অর্ডার সফলভাবে গ্রহণ করা হয়েছে</p>
      </motion.div>

      <motion.div
        ref={confirmationRef}
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.5, duration: 0.5 }}
        className="rounded-lg border bg-card/30 backdrop-blur-md p-8 shadow-lg overflow-hidden relative"
      >
        {/* Glass effect overlay */}
        <div className="absolute inset-0 bg-gradient-to-br from-green-500/5 to-blue-500/5"></div>

        <div className="relative z-10">
          <div className="flex justify-between items-center mb-6">
            <div>
              <h2 className="text-2xl font-bold">অর্ডার কনফার্মেশন</h2>
              <p className="text-muted-foreground">অর্ডার আইডি: {data.orderId}</p>
            </div>
            <div className="text-right">
              <p className="font-medium">তারিখ</p>
              <p className="text-muted-foreground">{data.date}</p>
            </div>
          </div>

          <Separator className="my-4" />

          <div className="space-y-4 my-6">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <h3 className="font-medium text-muted-foreground">পেমেন্ট মেথড</h3>
                <p className="font-medium">
                  {data.paymentMethod === "bkash" ? "বিকাশ" : data.paymentMethod === "nagad" ? "নগদ" : "রকেট"}
                </p>
              </div>
              <div>
                <h3 className="font-medium text-muted-foreground">ট্রানজেকশন আইডি</h3>
                <p className="font-medium">{data.transactionId}</p>
              </div>
            </div>
          </div>

          <div className="rounded-lg bg-muted/50 p-4 mb-6">
            <h3 className="font-medium mb-3">অর্ডার সামারি</h3>
            <div className="space-y-3">
              {data.items.map((item) => {
                const itemPrice = item.discount ? item.price - (item.price * item.discount) / 100 : item.price
                return (
                  <div key={item.id} className="flex justify-between text-sm">
                    <div className="flex items-center gap-2">
                      <div className="relative w-10 h-10 rounded-md overflow-hidden bg-background">
                        <Image src={item.image || "/placeholder.svg"} alt={item.name} fill className="object-cover" />
                      </div>
                      <div>
                        <p className="font-medium">{item.name}</p>
                        <p className="text-xs text-muted-foreground">x{item.quantity}</p>
                      </div>
                    </div>
                    <p className="font-medium">৳{itemPrice * item.quantity}</p>
                  </div>
                )
              })}
            </div>
          </div>

          <Separator className="my-4" />

          <div className="flex justify-between items-center font-bold text-lg">
            <span>মোট পরিশোধিত</span>
            <span className="text-primary">৳{data.amount}</span>
          </div>

          <div className="mt-8 text-center">
            <p className="text-muted-foreground text-sm mb-2">আপনার অর্ডার সম্পর্কে বিস্তারিত তথ্য আপনার ইমেইলে পাঠানো হয়েছে</p>
            <p className="text-green-600 font-medium">ধন্যবাদ আমাদের সাথে থাকার জন্য!</p>
          </div>
        </div>
      </motion.div>

      <div className="flex flex-col sm:flex-row gap-4 mt-8 justify-center">
        <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
          <Button onClick={downloadConfirmation} className="gap-2">
            <Download className="h-4 w-4" />
            কনফার্মেশন ডাউনলোড করুন
          </Button>
        </motion.div>

        <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
          <Button variant="outline" onClick={() => router.push("/")} className="gap-2">
            <Home className="h-4 w-4" />
            হোম পেজে ফিরুন
          </Button>
        </motion.div>

        <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
          <Button variant="outline" onClick={() => router.push("/products")} className="gap-2">
            <ShoppingBag className="h-4 w-4" />
            আরও শপিং করুন
          </Button>
        </motion.div>
      </div>
    </div>
  )
}
