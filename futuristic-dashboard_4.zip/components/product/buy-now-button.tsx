"use client"

import { Button } from "@/components/ui/button"
import { CreditCard } from "lucide-react"
import { useCart } from "@/context/cart-context"
import { motion } from "framer-motion"
import type { Product } from "@/types/product"

export default function BuyNowButton({ product }: { product: Product }) {
  const { addToCart } = useCart()

  const handleBuyNow = () => {
    addToCart(product, 1, true)
  }

  return (
    <motion.div className="flex-1" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
      <Button
        className="w-full gap-2 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
        onClick={handleBuyNow}
      >
        <CreditCard size={18} />
        এখনই কিনুন
      </Button>
    </motion.div>
  )
}
