"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Star, ThumbsUp, ThumbsDown, Flag } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

// Mock reviews data
const mockReviews = [
  {
    id: "1",
    user: {
      name: "আব্দুল্লাহ",
      avatar: "/placeholder.svg?height=40&width=40",
      initial: "আ",
    },
    rating: 5,
    date: "১০ মে, ২০২৩",
    content: "খুবই ভালো প্রোডাক্ট। আমি এটি ব্যবহার করে খুবই সন্তুষ্ট। এটি আমার প্রত্যাশা অনুযায়ী কাজ করছে এবং সাপোর্ট টিমও খুব সহযোগী।",
    helpful: 12,
    unhelpful: 2,
  },
  {
    id: "2",
    user: {
      name: "ফারহানা",
      avatar: "/placeholder.svg?height=40&width=40",
      initial: "ফা",
    },
    rating: 4,
    date: "০৫ মে, ২০২৩",
    content: "ভালো প্রোডাক্ট, তবে কিছু ফিচার আরও উন্নত করা যেতে পারে। যাইহোক, মূল্যের তুলনায় এটি একটি ভালো প্রোডাক্ট।",
    helpful: 8,
    unhelpful: 1,
  },
  {
    id: "3",
    user: {
      name: "রাকিব",
      avatar: "/placeholder.svg?height=40&width=40",
      initial: "রা",
    },
    rating: 5,
    date: "২৮ এপ্রিল, ২০২৩",
    content: "দারুণ প্রোডাক্ট! আমি এটি ব্যবহার করে খুবই খুশি। ডকুমেন্টেশন খুব ভালো এবং ব্যবহার করা খুব সহজ। আমি এটি সবাইকে সুপারিশ করব।",
    helpful: 15,
    unhelpful: 0,
  },
]

export default function ProductReviews({ productId }: { productId: string }) {
  const [reviews, setReviews] = useState(mockReviews)
  const [newReview, setNewReview] = useState("")
  const [rating, setRating] = useState(0)
  const [hoveredRating, setHoveredRating] = useState(0)
  const { toast } = useToast()

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (rating === 0) {
      toast({
        title: "রেটিং দিন",
        description: "রিভিউ জমা দেওয়ার আগে রেটিং দিন।",
        variant: "destructive",
      })
      return
    }

    if (!newReview.trim()) {
      toast({
        title: "রিভিউ লিখুন",
        description: "রিভিউ জমা দেওয়ার আগে আপনার মতামত লিখুন।",
        variant: "destructive",
      })
      return
    }

    // Here you would typically send this to your API
    const newReviewObj = {
      id: `${reviews.length + 1}`,
      user: {
        name: "আপনি",
        avatar: "/placeholder.svg?height=40&width=40",
        initial: "আ",
      },
      rating,
      date: "আজ",
      content: newReview,
      helpful: 0,
      unhelpful: 0,
    }

    setReviews([newReviewObj, ...reviews])
    setNewReview("")
    setRating(0)

    toast({
      title: "রিভিউ জমা দেওয়া হয়েছে",
      description: "আপনার রিভিউ সফলভাবে জমা দেওয়া হয়েছে।",
    })
  }

  const handleHelpful = (id: string, type: "helpful" | "unhelpful") => {
    setReviews(
      reviews.map((review) => {
        if (review.id === id) {
          return {
            ...review,
            [type]: review[type] + 1,
          }
        }
        return review
      }),
    )
  }

  return (
    <div>
      <div className="mb-8">
        <h3 className="text-lg font-bold mb-4">রিভিউ লিখুন</h3>

        <form onSubmit={handleReviewSubmit}>
          <div className="mb-4">
            <div className="flex items-center mb-2">
              <span className="mr-2">আপনার রেটিং:</span>
              <div className="flex">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    type="button"
                    onClick={() => setRating(star)}
                    onMouseEnter={() => setHoveredRating(star)}
                    onMouseLeave={() => setHoveredRating(0)}
                    className="focus:outline-none"
                  >
                    <Star
                      size={24}
                      className={`${
                        star <= (hoveredRating || rating) ? "text-yellow-500 fill-yellow-500" : "text-gray-300"
                      } cursor-pointer`}
                    />
                  </button>
                ))}
              </div>
            </div>

            <Textarea
              placeholder="আপনার অভিজ্ঞতা শেয়ার করুন..."
              rows={4}
              value={newReview}
              onChange={(e) => setNewReview(e.target.value)}
              className="mb-2"
            />

            <Button type="submit">রিভিউ জমা দিন</Button>
          </div>
        </form>
      </div>

      <div className="space-y-6">
        <h3 className="text-lg font-bold">গ্রাহকদের রিভিউ ({reviews.length})</h3>

        {reviews.length > 0 ? (
          <div className="space-y-6">
            {reviews.map((review) => (
              <div key={review.id} className="border-b pb-6">
                <div className="flex items-start">
                  <Avatar className="h-10 w-10 mr-4">
                    <AvatarImage src={review.user.avatar || "/placeholder.svg"} alt={review.user.name} />
                    <AvatarFallback>{review.user.initial}</AvatarFallback>
                  </Avatar>

                  <div className="flex-1">
                    <div className="flex items-center">
                      <h4 className="font-medium">{review.user.name}</h4>
                      <span className="text-muted-foreground text-sm ml-2">{review.date}</span>
                    </div>

                    <div className="flex my-1">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          size={16}
                          className={i < review.rating ? "text-yellow-500 fill-yellow-500" : "text-gray-300"}
                        />
                      ))}
                    </div>

                    <p className="text-muted-foreground mt-2">{review.content}</p>

                    <div className="flex items-center mt-4 space-x-4 text-sm">
                      <button
                        className="flex items-center text-muted-foreground hover:text-foreground"
                        onClick={() => handleHelpful(review.id, "helpful")}
                      >
                        <ThumbsUp size={14} className="mr-1" />
                        সাহায্যকারী ({review.helpful})
                      </button>

                      <button
                        className="flex items-center text-muted-foreground hover:text-foreground"
                        onClick={() => handleHelpful(review.id, "unhelpful")}
                      >
                        <ThumbsDown size={14} className="mr-1" />
                        সাহায্যকারী নয় ({review.unhelpful})
                      </button>

                      <button className="flex items-center text-muted-foreground hover:text-foreground">
                        <Flag size={14} className="mr-1" />
                        রিপোর্ট
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8 text-muted-foreground">এখনও কোন রিভিউ নেই। প্রথম রিভিউ দিন!</div>
        )}
      </div>
    </div>
  )
}
