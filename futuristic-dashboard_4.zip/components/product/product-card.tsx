"use client"

import Image from "next/image"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Star, ShoppingCart, Eye, CreditCard } from "lucide-react"
import type { Product } from "@/types/product"
import { useCart } from "@/context/cart-context"
import { motion } from "framer-motion"

export function ProductCard({ product }: { product: Product }) {
  const { addToCart } = useCart()

  return (
    <motion.div
      className="group rounded-lg border bg-card overflow-hidden transition-all hover:shadow-md"
      whileHover={{ y: -5, boxShadow: "0 10px 30px rgba(0, 0, 0, 0.1)" }}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className="relative aspect-square overflow-hidden bg-muted">
        <Image
          src={product.image || "/placeholder.svg"}
          alt={product.name}
          fill
          className="object-cover transition-transform group-hover:scale-105"
        />

        {product.discount > 0 && (
          <Badge className="absolute top-2 right-2 bg-red-500 hover:bg-red-600">{product.discount}% ছাড়</Badge>
        )}

        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
          <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
            <Button asChild size="sm" variant="secondary" className="rounded-full">
              <Link href={`/products/${product.id}`}>
                <Eye className="h-4 w-4 mr-1" />
                দেখুন
              </Link>
            </Button>
          </motion.div>

          <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
            <Button size="sm" variant="secondary" className="rounded-full" onClick={() => addToCart(product)}>
              <ShoppingCart className="h-4 w-4 mr-1" />
              কার্টে যোগ করুন
            </Button>
          </motion.div>

          <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
            <Button
              size="sm"
              variant="default"
              className="rounded-full bg-primary"
              onClick={() => addToCart(product, 1, true)}
            >
              <CreditCard className="h-4 w-4 mr-1" />
              কিনুন
            </Button>
          </motion.div>
        </div>
      </div>

      <div className="p-4">
        <Link href={`/products/${product.id}`} className="block">
          <h3 className="font-medium line-clamp-1 group-hover:text-primary transition-colors">{product.name}</h3>
        </Link>

        <div className="flex items-center mt-1 mb-2">
          <div className="flex">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                size={14}
                className={i < product.rating ? "text-yellow-500 fill-yellow-500" : "text-gray-300"}
              />
            ))}
          </div>
          <span className="text-xs text-muted-foreground ml-1">({product.reviews})</span>
        </div>

        <div className="flex items-center justify-between">
          <div>
            {product.discount ? (
              <div className="flex items-center gap-1">
                <span className="font-bold">৳{product.price - (product.price * product.discount) / 100}</span>
                <span className="text-sm text-muted-foreground line-through">৳{product.price}</span>
              </div>
            ) : (
              <span className="font-bold">৳{product.price}</span>
            )}
          </div>

          <Badge variant="outline" className="text-xs">
            {product.category}
          </Badge>
        </div>
      </div>
    </motion.div>
  )
}
