"use client"

import { useState } from "react"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Clock, Sparkles } from "lucide-react"

const categories = [
  { id: "software", label: "সফটওয়্যার" },
  { id: "template", label: "টেমপ্লেট" },
  { id: "ebook", label: "ই-বুক" },
  { id: "course", label: "কোর্স" },
  { id: "graphics", label: "গ্রাফিক্স" },
  { id: "ui-kit", label: "ইউআই কিট" },
  { id: "audio", label: "অডিও" },
  { id: "video", label: "ভিডিও" },
]

const ratings = [
  { id: "5", label: "৫ স্টার" },
  { id: "4", label: "৪ স্টার এবং উপরে" },
  { id: "3", label: "৩ স্টার এবং উপরে" },
  { id: "2", label: "২ স্টার এবং উপরে" },
  { id: "1", label: "১ স্টার এবং উপরে" },
]

export function ProductFilters() {
  const [priceRange, setPriceRange] = useState([0, 5000])
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [selectedRatings, setSelectedRatings] = useState<string[]>([])

  const handleCategoryChange = (category: string) => {
    setSelectedCategories((prev) =>
      prev.includes(category) ? prev.filter((c) => c !== category) : [...prev, category],
    )
  }

  const handleRatingChange = (rating: string) => {
    setSelectedRatings((prev) => (prev.includes(rating) ? prev.filter((r) => r !== rating) : [...prev, rating]))
  }

  const handlePriceChange = (values: number[]) => {
    setPriceRange(values)
  }

  const resetFilters = () => {
    setPriceRange([0, 5000])
    setSelectedCategories([])
    setSelectedRatings([])
  }

  return (
    <div className="neon-filter-container relative p-0.5 rounded-lg overflow-hidden">
      {/* Neon border effect */}
      <div className="absolute inset-0 bg-gradient-to-r from-purple-500 via-fuchsia-500 to-blue-500 opacity-80 animate-neon-pulse rounded-lg"></div>
      <div className="absolute inset-0 bg-gradient-to-r from-purple-500 via-fuchsia-500 to-blue-500 blur-md animate-neon-pulse rounded-lg"></div>

      {/* 30% off badge */}
      <div className="absolute -top-5 -right-5 z-20">
        <div className="relative">
          <div className="absolute inset-0 bg-yellow-400 rounded-full blur-sm animate-pulse"></div>
          <div className="relative bg-gradient-to-br from-yellow-300 to-yellow-500 w-24 h-24 rounded-full flex flex-col items-center justify-center transform rotate-12 border-4 border-white shadow-xl">
            <div className="text-2xl font-bold text-white drop-shadow-md">৩০%</div>
            <div className="text-lg font-bold text-white drop-shadow-md">ছাড়!</div>
          </div>
          <div className="absolute inset-0 bg-gradient-to-r from-yellow-400 to-orange-400 rounded-full opacity-30 animate-ping"></div>
        </div>
      </div>

      {/* Main content */}
      <div className="relative bg-card dark:bg-slate-900/95 backdrop-blur-sm rounded-lg p-6 space-y-6 shadow-xl z-10">
        {/* Limited time offer banner */}
        <div className="bg-gradient-to-r from-purple-600/20 to-blue-600/20 rounded-lg p-3 mb-4 border border-purple-500/30">
          <div className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-yellow-400" />
            <div className="flex-1">
              <h3 className="font-medium text-sm">সীমিত সময়ের অফার!</h3>
              <p className="text-xs text-muted-foreground">সকল প্রোডাক্টে ৩০% ছাড়</p>
            </div>
            <div className="flex items-center gap-1 text-xs bg-purple-600/20 px-2 py-1 rounded-full">
              <Clock className="h-3 w-3" />
              <span>৩ দিন বাকি</span>
            </div>
          </div>
        </div>

        <div>
          <h3 className="font-medium mb-4 text-lg">ফিল্টার</h3>
          <Button
            variant="outline"
            size="sm"
            onClick={resetFilters}
            className="hover:bg-purple-500/10 hover:text-purple-500 transition-colors"
          >
            রিসেট করুন
          </Button>
        </div>

        <Accordion type="multiple" defaultValue={["price", "category", "rating"]} className="w-full">
          <AccordionItem value="price" className="border-b-purple-500/30">
            <AccordionTrigger className="hover:text-purple-500">মূল্য</AccordionTrigger>
            <AccordionContent>
              <div className="space-y-4">
                <Slider
                  defaultValue={[0, 5000]}
                  max={5000}
                  step={100}
                  value={priceRange}
                  onValueChange={handlePriceChange}
                  className="[&>span[data-orientation=horizontal]]:h-2 [&>span[data-orientation=horizontal]]:bg-gradient-to-r [&>span[data-orientation=horizontal]]:from-purple-500/20 [&>span[data-orientation=horizontal]]:to-blue-500/20"
                />

                <div className="flex items-center justify-between">
                  <span className="text-purple-500 font-medium">৳{priceRange[0]}</span>
                  <span className="text-blue-500 font-medium">৳{priceRange[1]}</span>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="category" className="border-b-purple-500/30">
            <AccordionTrigger className="hover:text-purple-500">ক্যাটাগরি</AccordionTrigger>
            <AccordionContent>
              <div className="space-y-2">
                {categories.map((category) => (
                  <div key={category.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={`category-${category.id}`}
                      checked={selectedCategories.includes(category.id)}
                      onCheckedChange={() => handleCategoryChange(category.id)}
                      className="data-[state=checked]:bg-purple-500 data-[state=checked]:border-purple-500"
                    />
                    <Label htmlFor={`category-${category.id}`} className="text-sm cursor-pointer hover:text-purple-500">
                      {category.label}
                    </Label>
                  </div>
                ))}
              </div>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="rating" className="border-b-purple-500/30">
            <AccordionTrigger className="hover:text-purple-500">রেটিং</AccordionTrigger>
            <AccordionContent>
              <div className="space-y-2">
                {ratings.map((rating) => (
                  <div key={rating.id} className="flex items-center space-x-2">
                    <Checkbox
                      id={`rating-${rating.id}`}
                      checked={selectedRatings.includes(rating.id)}
                      onCheckedChange={() => handleRatingChange(rating.id)}
                      className="data-[state=checked]:bg-purple-500 data-[state=checked]:border-purple-500"
                    />
                    <Label htmlFor={`rating-${rating.id}`} className="text-sm cursor-pointer hover:text-purple-500">
                      {rating.label}
                    </Label>
                  </div>
                ))}
              </div>
            </AccordionContent>
          </AccordionItem>

          <AccordionItem value="discount" className="border-b-purple-500/30">
            <AccordionTrigger className="hover:text-purple-500">ডিসকাউন্ট</AccordionTrigger>
            <AccordionContent>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="discount-any"
                    className="data-[state=checked]:bg-purple-500 data-[state=checked]:border-purple-500"
                  />
                  <Label htmlFor="discount-any" className="text-sm cursor-pointer hover:text-purple-500">
                    যেকোনো ডিসকাউন্ট
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="discount-10"
                    className="data-[state=checked]:bg-purple-500 data-[state=checked]:border-purple-500"
                  />
                  <Label htmlFor="discount-10" className="text-sm cursor-pointer hover:text-purple-500">
                    ১০% বা তার বেশি
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="discount-20"
                    className="data-[state=checked]:bg-purple-500 data-[state=checked]:border-purple-500"
                  />
                  <Label htmlFor="discount-20" className="text-sm cursor-pointer hover:text-purple-500">
                    ২০% বা তার বেশি
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="discount-30"
                    className="data-[state=checked]:bg-purple-500 data-[state=checked]:border-purple-500"
                  />
                  <Label htmlFor="discount-30" className="text-sm cursor-pointer hover:text-purple-500 font-medium">
                    ৩০% বা তার বেশি
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="discount-50"
                    className="data-[state=checked]:bg-purple-500 data-[state=checked]:border-purple-500"
                  />
                  <Label htmlFor="discount-50" className="text-sm cursor-pointer hover:text-purple-500">
                    ৫০% বা তার বেশি
                  </Label>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>

        <div className="pt-4 border-t border-purple-500/30">
          <Button className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white">
            ফিল্টার প্রয়োগ করুন
          </Button>
        </div>
      </div>
    </div>
  )
}
